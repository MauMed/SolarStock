-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 05-10-2026 a las 22:03:35
-- Versión del servidor: 11.4.13-MariaDB-cll-lve
-- Versión de PHP: 8.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alfageza_solarstock`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacen`
--

CREATE TABLE `almacen` (
  `id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `api_key`
--

CREATE TABLE `api_key` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `llave` char(64) NOT NULL,
  `permisos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`permisos`)),
  `activa` tinyint(1) DEFAULT 1,
  `ultimo_uso` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `padre_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `tipo_doc_sin` int(11) NOT NULL DEFAULT 1,
  `num_documento` varchar(20) NOT NULL,
  `complemento` varchar(3) DEFAULT NULL,
  `razon_social` varchar(200) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `externo_ref` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `almacen_id` int(11) NOT NULL,
  `nro_documento` varchar(40) DEFAULT NULL,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `moneda` char(3) NOT NULL DEFAULT 'BOB',
  `tipo_cambio` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `total_moneda` decimal(14,2) DEFAULT NULL,
  `costos_adicionales` text DEFAULT NULL,
  `total_costos` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_landed` decimal(14,2) NOT NULL DEFAULT 0.00,
  `estado` enum('BORRADOR','RECIBIDA','ANULADA') DEFAULT 'RECIBIDA',
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp(),
  `pagada` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_pago` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra_detalle`
--

CREATE TABLE `compra_detalle` (
  `id` bigint(20) NOT NULL,
  `compra_id` bigint(20) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` decimal(14,3) NOT NULL,
  `costo_unit` decimal(14,4) NOT NULL,
  `costo_landed_unit` decimal(14,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `id` int(11) NOT NULL,
  `nit` varchar(15) NOT NULL,
  `razon_social` varchar(200) NOT NULL,
  `nombre_comercial` varchar(120) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `municipio` varchar(100) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `facturacion_activa` tinyint(1) NOT NULL DEFAULT 0,
  `proforma_validez_dias` int(11) NOT NULL DEFAULT 15,
  `proforma_condiciones` text DEFAULT NULL,
  `visibilidad` text DEFAULT NULL,
  `margen_objetivo_pct` decimal(5,2) NOT NULL DEFAULT 25.00,
  `dias_reposicion` int(11) NOT NULL DEFAULT 30,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `color_primario` char(7) NOT NULL DEFAULT '#b91c1c',
  `color_acento` char(7) NOT NULL DEFAULT '#f59e0b',
  `color_menu` char(7) NOT NULL DEFAULT '#71717a',
  `fuente_menu` varchar(120) NOT NULL DEFAULT 'system-ui',
  `rubro` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id` bigint(20) NOT NULL,
  `venta_id` bigint(20) DEFAULT NULL,
  `siat_config_id` int(11) NOT NULL,
  `cufd_id` bigint(20) NOT NULL,
  `numero_factura` bigint(20) NOT NULL,
  `cuf` varchar(80) NOT NULL,
  `fecha_emision` datetime(3) NOT NULL,
  `tipo_emision` int(11) NOT NULL DEFAULT 1,
  `tipo_factura` int(11) NOT NULL DEFAULT 1,
  `doc_sector` int(11) NOT NULL DEFAULT 1,
  `cliente_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`cliente_snapshot`)),
  `monto_total` decimal(14,2) NOT NULL,
  `estado` enum('PENDIENTE','EN_PROCESAMIENTO','VALIDA','RECHAZADA','ANULADA') NOT NULL DEFAULT 'PENDIENTE',
  `codigo_recepcion` varchar(80) DEFAULT NULL,
  `error_codigo` varchar(20) DEFAULT NULL,
  `error_descripcion` text DEFAULT NULL,
  `motivo_anulacion` int(11) DEFAULT NULL,
  `xml` longtext DEFAULT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `evento_id` bigint(20) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura_recibida`
--

CREATE TABLE `factura_recibida` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nit_proveedor` varchar(15) NOT NULL,
  `razon_social` varchar(200) DEFAULT NULL,
  `numero_factura` bigint(20) DEFAULT NULL,
  `cuf` varchar(80) DEFAULT NULL,
  `fecha_emision` datetime DEFAULT NULL,
  `monto_total` decimal(14,2) DEFAULT NULL,
  `codigo_control` varchar(60) DEFAULT NULL,
  `origen` enum('QR_SCAN','IMPORT_SIAT','MANUAL') DEFAULT 'QR_SCAN',
  `compra_id` bigint(20) DEFAULT NULL,
  `verificada` tinyint(1) DEFAULT 0,
  `datos_raw` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos_raw`)),
  `creado_en` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impresora`
--

CREATE TABLE `impresora` (
  `id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('TERMICA_RED','TERMICA_BT','LASER_TINTA') NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `puerto` int(11) DEFAULT 9100,
  `ancho_mm` int(11) DEFAULT 80,
  `predeterminada` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `almacen_id` int(11) NOT NULL,
  `tipo` enum('COMPRA','VENTA','AJUSTE+','AJUSTE-','TRASPASO_IN','TRASPASO_OUT','DEVOLUCION') NOT NULL,
  `cantidad` decimal(14,3) NOT NULL,
  `costo_unit` decimal(14,4) DEFAULT 0.0000,
  `saldo_resultante` decimal(14,3) NOT NULL,
  `referencia_tipo` varchar(30) DEFAULT NULL,
  `referencia_id` bigint(20) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

CREATE TABLE `permiso` (
  `clave` varchar(60) NOT NULL,
  `modulo` varchar(40) NOT NULL,
  `descripcion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `codigo_interno` varchar(50) NOT NULL,
  `codigo_barras` varchar(64) DEFAULT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `unidad_medida_sin` int(11) DEFAULT 58,
  `precio_compra` decimal(14,4) DEFAULT 0.0000,
  `precio_venta` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `stock_minimo` decimal(12,3) DEFAULT 0.000,
  `dias_reposicion` int(11) DEFAULT NULL,
  `maneja_lotes` tinyint(1) DEFAULT 0,
  `imagen_url` varchar(255) DEFAULT NULL,
  `codigo_actividad_sin` varchar(20) DEFAULT NULL,
  `codigo_producto_sin` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `externo_ref` varchar(80) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma`
--

CREATE TABLE `proforma` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `almacen_id` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `cliente_nombre` varchar(200) DEFAULT NULL,
  `cliente_documento` varchar(30) DEFAULT NULL,
  `cliente_email` varchar(150) DEFAULT NULL,
  `cliente_telefono` varchar(30) DEFAULT NULL,
  `subtotal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `descuento` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `validez_dias` int(11) NOT NULL DEFAULT 15,
  `valida_hasta` date NOT NULL,
  `estado` enum('BORRADOR','ENVIADA','ACEPTADA','CONVERTIDA','VENCIDA','ANULADA') NOT NULL DEFAULT 'BORRADOR',
  `observaciones` text DEFAULT NULL,
  `condiciones` text DEFAULT NULL,
  `venta_id` bigint(20) DEFAULT NULL,
  `enviada_email` varchar(150) DEFAULT NULL,
  `enviada_en` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma_detalle`
--

CREATE TABLE `proforma_detalle` (
  `id` bigint(20) NOT NULL,
  `proforma_id` bigint(20) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `cantidad` decimal(14,3) NOT NULL,
  `precio_unit` decimal(14,4) NOT NULL,
  `descuento` decimal(14,2) NOT NULL DEFAULT 0.00,
  `orden` smallint(6) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `nit` varchar(20) DEFAULT NULL,
  `razon_social` varchar(200) NOT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `punto_venta`
--

CREATE TABLE `punto_venta` (
  `id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `codigo_sin` int(11) NOT NULL DEFAULT 0,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion`
--

CREATE TABLE `sesion` (
  `token` char(64) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `expira` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_actividad`
--

CREATE TABLE `siat_actividad` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `codigo_actividad` varchar(20) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_config`
--

CREATE TABLE `siat_config` (
  `id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `punto_venta_id` int(11) DEFAULT NULL,
  `nit_emisor` varchar(15) NOT NULL,
  `codigo_sistema` varchar(40) NOT NULL,
  `token_delegado` text NOT NULL,
  `token_expira` date NOT NULL,
  `ambiente` enum('HOMOLOGACION','PRODUCCION') DEFAULT 'HOMOLOGACION',
  `modalidad` int(11) DEFAULT 2,
  `cuis` varchar(30) DEFAULT NULL,
  `cuis_expira` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_cufd`
--

CREATE TABLE `siat_cufd` (
  `id` bigint(20) NOT NULL,
  `siat_config_id` int(11) NOT NULL,
  `codigo_cufd` varchar(120) NOT NULL,
  `codigo_control` varchar(60) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_evento`
--

CREATE TABLE `siat_evento` (
  `id` bigint(20) NOT NULL,
  `siat_config_id` int(11) NOT NULL,
  `codigo_evento` int(11) NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `codigo_recepcion_evento` varchar(80) DEFAULT NULL,
  `estado` enum('ABIERTO','CERRADO','REPORTADO') DEFAULT 'ABIERTO'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_log`
--

CREATE TABLE `siat_log` (
  `id` bigint(20) NOT NULL,
  `factura_id` bigint(20) DEFAULT NULL,
  `origen` varchar(40) NOT NULL,
  `gravedad` enum('CONEXION','VALIDACION','INFO') NOT NULL,
  `codigo_error` varchar(20) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_parametro`
--

CREATE TABLE `siat_parametro` (
  `id` int(11) NOT NULL,
  `grupo` varchar(40) NOT NULL,
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `siat_producto_sin`
--

CREATE TABLE `siat_producto_sin` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `codigo_actividad` varchar(20) NOT NULL,
  `codigo_producto` varchar(20) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sin_venta_externa`
--

CREATE TABLE `sin_venta_externa` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `cuf` varchar(80) DEFAULT NULL,
  `numero_factura` bigint(20) DEFAULT NULL,
  `nit_cliente` varchar(20) DEFAULT NULL,
  `razon_social` varchar(200) DEFAULT NULL,
  `fecha_emision` datetime DEFAULT NULL,
  `monto_total` decimal(14,2) NOT NULL DEFAULT 0.00,
  `origen` enum('IMPORT_CSV','API','MANUAL') DEFAULT 'IMPORT_CSV',
  `estado` enum('CONCILIADA_INTERNA','EXTERNA_PENDIENTE','DESCONTADA','IGNORADA') NOT NULL DEFAULT 'EXTERNA_PENDIENTE',
  `almacen_id` int(11) DEFAULT NULL,
  `datos_raw` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`datos_raw`)),
  `creado_en` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sin_venta_externa_item`
--

CREATE TABLE `sin_venta_externa_item` (
  `id` bigint(20) NOT NULL,
  `venta_externa_id` bigint(20) NOT NULL,
  `codigo_producto` varchar(64) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `cantidad` decimal(14,3) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `descontado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stock`
--

CREATE TABLE `stock` (
  `producto_id` int(11) NOT NULL,
  `almacen_id` int(11) NOT NULL,
  `cantidad` decimal(14,3) NOT NULL DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursal`
--

CREATE TABLE `sucursal` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `codigo_sin` int(11) NOT NULL DEFAULT 0,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `activa` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `sucursal_id` int(11) DEFAULT NULL,
  `nombre` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `pass_hash` varchar(255) NOT NULL,
  `rol` enum('admin','gerente','cajero','almacen','auditor') NOT NULL DEFAULT 'cajero',
  `activo` tinyint(1) DEFAULT 1,
  `ultimo_login` timestamp NULL DEFAULT NULL,
  `reset_token` char(64) DEFAULT NULL,
  `reset_expira` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_permiso`
--

CREATE TABLE `usuario_permiso` (
  `usuario_id` int(11) NOT NULL,
  `permiso_clave` varchar(60) NOT NULL,
  `concedido` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `id` bigint(20) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `punto_venta_id` int(11) DEFAULT NULL,
  `almacen_id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `subtotal` decimal(14,2) NOT NULL,
  `descuento` decimal(14,2) DEFAULT 0.00,
  `total` decimal(14,2) NOT NULL,
  `metodo_pago_sin` int(11) DEFAULT 1,
  `estado` enum('COMPLETADA','ANULADA') DEFAULT 'COMPLETADA',
  `origen` enum('POS','API','ECOMMERCE') DEFAULT 'POS',
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT current_timestamp(),
  `pagada` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_pago` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta_detalle`
--

CREATE TABLE `venta_detalle` (
  `id` bigint(20) NOT NULL,
  `venta_id` bigint(20) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` decimal(14,3) NOT NULL,
  `precio_unit` decimal(14,4) NOT NULL,
  `descuento` decimal(14,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `webhook`
--

CREATE TABLE `webhook` (
  `id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `evento` varchar(60) NOT NULL,
  `url` varchar(255) NOT NULL,
  `secreto` varchar(64) NOT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `webhook_intento`
--

CREATE TABLE `webhook_intento` (
  `id` bigint(20) NOT NULL,
  `webhook_id` int(11) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `http_status` int(11) DEFAULT NULL,
  `intentos` int(11) DEFAULT 0,
  `estado` enum('PENDIENTE','OK','FALLIDO') DEFAULT 'PENDIENTE',
  `proximo_intento` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sucursal_id` (`sucursal_id`);

--
-- Indices de la tabla `api_key`
--
ALTER TABLE `api_key`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `llave` (`llave`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_doc` (`empresa_id`,`num_documento`);

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `compra_detalle`
--
ALTER TABLE `compra_detalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `compra_id` (`compra_id`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cuf` (`cuf`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `cufd_id` (`cufd_id`);

--
-- Indices de la tabla `factura_recibida`
--
ALTER TABLE `factura_recibida`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_fr` (`empresa_id`,`nit_proveedor`,`numero_factura`,`cuf`);

--
-- Indices de la tabla `impresora`
--
ALTER TABLE `impresora`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sucursal_id` (`sucursal_id`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_prod_fecha` (`producto_id`,`fecha`);

--
-- Indices de la tabla `permiso`
--
ALTER TABLE `permiso`
  ADD PRIMARY KEY (`clave`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_prod` (`empresa_id`,`codigo_interno`),
  ADD KEY `idx_barras` (`codigo_barras`);

--
-- Indices de la tabla `proforma`
--
ALTER TABLE `proforma`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_proforma_numero` (`empresa_id`,`numero`),
  ADD KEY `ix_proforma_estado` (`empresa_id`,`estado`,`valida_hasta`),
  ADD KEY `ix_proforma_cliente` (`cliente_id`),
  ADD KEY `sucursal_id` (`sucursal_id`),
  ADD KEY `almacen_id` (`almacen_id`),
  ADD KEY `venta_id` (`venta_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `proforma_detalle`
--
ALTER TABLE `proforma_detalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proforma_id` (`proforma_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `punto_venta`
--
ALTER TABLE `punto_venta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sucursal_id` (`sucursal_id`);

--
-- Indices de la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD PRIMARY KEY (`token`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `siat_actividad`
--
ALTER TABLE `siat_actividad`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_act` (`empresa_id`,`codigo_actividad`);

--
-- Indices de la tabla `siat_config`
--
ALTER TABLE `siat_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cfg` (`sucursal_id`,`punto_venta_id`);

--
-- Indices de la tabla `siat_cufd`
--
ALTER TABLE `siat_cufd`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vigencia` (`siat_config_id`,`fecha_fin`);

--
-- Indices de la tabla `siat_evento`
--
ALTER TABLE `siat_evento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siat_config_id` (`siat_config_id`);

--
-- Indices de la tabla `siat_log`
--
ALTER TABLE `siat_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fac` (`factura_id`);

--
-- Indices de la tabla `siat_parametro`
--
ALTER TABLE `siat_parametro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_par` (`grupo`,`codigo`);

--
-- Indices de la tabla `siat_producto_sin`
--
ALTER TABLE `siat_producto_sin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ps` (`empresa_id`,`codigo_actividad`,`codigo_producto`);

--
-- Indices de la tabla `sin_venta_externa`
--
ALTER TABLE `sin_venta_externa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sve` (`empresa_id`,`cuf`,`numero_factura`);

--
-- Indices de la tabla `sin_venta_externa_item`
--
ALTER TABLE `sin_venta_externa_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venta_externa_id` (`venta_externa_id`);

--
-- Indices de la tabla `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`producto_id`,`almacen_id`),
  ADD KEY `almacen_id` (`almacen_id`);

--
-- Indices de la tabla `sucursal`
--
ALTER TABLE `sucursal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
  ADD PRIMARY KEY (`usuario_id`,`permiso_clave`),
  ADD KEY `permiso_clave` (`permiso_clave`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `venta_detalle`
--
ALTER TABLE `venta_detalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venta_id` (`venta_id`);

--
-- Indices de la tabla `webhook`
--
ALTER TABLE `webhook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empresa_id` (`empresa_id`);

--
-- Indices de la tabla `webhook_intento`
--
ALTER TABLE `webhook_intento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webhook_id` (`webhook_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `almacen`
--
ALTER TABLE `almacen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `api_key`
--
ALTER TABLE `api_key`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `compra`
--
ALTER TABLE `compra`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `compra_detalle`
--
ALTER TABLE `compra_detalle`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `factura_recibida`
--
ALTER TABLE `factura_recibida`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `impresora`
--
ALTER TABLE `impresora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proforma`
--
ALTER TABLE `proforma`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proforma_detalle`
--
ALTER TABLE `proforma_detalle`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `punto_venta`
--
ALTER TABLE `punto_venta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_actividad`
--
ALTER TABLE `siat_actividad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_config`
--
ALTER TABLE `siat_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_cufd`
--
ALTER TABLE `siat_cufd`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_evento`
--
ALTER TABLE `siat_evento`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_log`
--
ALTER TABLE `siat_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_parametro`
--
ALTER TABLE `siat_parametro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `siat_producto_sin`
--
ALTER TABLE `siat_producto_sin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sin_venta_externa`
--
ALTER TABLE `sin_venta_externa`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sin_venta_externa_item`
--
ALTER TABLE `sin_venta_externa_item`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `sucursal`
--
ALTER TABLE `sucursal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `venta_detalle`
--
ALTER TABLE `venta_detalle`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `webhook`
--
ALTER TABLE `webhook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `webhook_intento`
--
ALTER TABLE `webhook_intento`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD CONSTRAINT `almacen_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`);

--
-- Filtros para la tabla `api_key`
--
ALTER TABLE `api_key`
  ADD CONSTRAINT `api_key_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD CONSTRAINT `categoria_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `compra_detalle`
--
ALTER TABLE `compra_detalle`
  ADD CONSTRAINT `compra_detalle_ibfk_1` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`cufd_id`) REFERENCES `siat_cufd` (`id`);

--
-- Filtros para la tabla `factura_recibida`
--
ALTER TABLE `factura_recibida`
  ADD CONSTRAINT `factura_recibida_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `impresora`
--
ALTER TABLE `impresora`
  ADD CONSTRAINT `impresora_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`);

--
-- Filtros para la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD CONSTRAINT `movimiento_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `proforma`
--
ALTER TABLE `proforma`
  ADD CONSTRAINT `proforma_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`),
  ADD CONSTRAINT `proforma_ibfk_2` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`),
  ADD CONSTRAINT `proforma_ibfk_3` FOREIGN KEY (`almacen_id`) REFERENCES `almacen` (`id`),
  ADD CONSTRAINT `proforma_ibfk_4` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `proforma_ibfk_5` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `proforma_ibfk_6` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `proforma_detalle`
--
ALTER TABLE `proforma_detalle`
  ADD CONSTRAINT `proforma_detalle_ibfk_1` FOREIGN KEY (`proforma_id`) REFERENCES `proforma` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proforma_detalle_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`);

--
-- Filtros para la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD CONSTRAINT `proveedor_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `punto_venta`
--
ALTER TABLE `punto_venta`
  ADD CONSTRAINT `punto_venta_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`);

--
-- Filtros para la tabla `sesion`
--
ALTER TABLE `sesion`
  ADD CONSTRAINT `sesion_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `siat_config`
--
ALTER TABLE `siat_config`
  ADD CONSTRAINT `siat_config_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursal` (`id`);

--
-- Filtros para la tabla `siat_cufd`
--
ALTER TABLE `siat_cufd`
  ADD CONSTRAINT `siat_cufd_ibfk_1` FOREIGN KEY (`siat_config_id`) REFERENCES `siat_config` (`id`);

--
-- Filtros para la tabla `siat_evento`
--
ALTER TABLE `siat_evento`
  ADD CONSTRAINT `siat_evento_ibfk_1` FOREIGN KEY (`siat_config_id`) REFERENCES `siat_config` (`id`);

--
-- Filtros para la tabla `sin_venta_externa`
--
ALTER TABLE `sin_venta_externa`
  ADD CONSTRAINT `sin_venta_externa_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `sin_venta_externa_item`
--
ALTER TABLE `sin_venta_externa_item`
  ADD CONSTRAINT `sin_venta_externa_item_ibfk_1` FOREIGN KEY (`venta_externa_id`) REFERENCES `sin_venta_externa` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  ADD CONSTRAINT `stock_ibfk_2` FOREIGN KEY (`almacen_id`) REFERENCES `almacen` (`id`);

--
-- Filtros para la tabla `sucursal`
--
ALTER TABLE `sucursal`
  ADD CONSTRAINT `sucursal_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
  ADD CONSTRAINT `usuario_permiso_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `usuario_permiso_ibfk_2` FOREIGN KEY (`permiso_clave`) REFERENCES `permiso` (`clave`) ON DELETE CASCADE;

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `venta_detalle`
--
ALTER TABLE `venta_detalle`
  ADD CONSTRAINT `venta_detalle_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `webhook`
--
ALTER TABLE `webhook`
  ADD CONSTRAINT `webhook_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`id`);

--
-- Filtros para la tabla `webhook_intento`
--
ALTER TABLE `webhook_intento`
  ADD CONSTRAINT `webhook_intento_ibfk_1` FOREIGN KEY (`webhook_id`) REFERENCES `webhook` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
