-- =====================================================================
-- V7: informes y KPIs elegibles, reposicion sugerida y costos de importacion
-- =====================================================================
USE inventario_sin;

-- ---------- Informes y KPIs elegibles (interruptores por empresa) ----------
-- JSON {"informes_ocultos":["ventas_horario",...],"kpis_ocultos":["ticket_promedio",...]}
-- NULL o vacio = todo visible. Se guarda lo OCULTO para que los informes y
-- KPIs que se agreguen en el futuro aparezcan visibles por defecto.
ALTER TABLE empresa
  ADD COLUMN visibilidad TEXT NULL AFTER proforma_condiciones,
  -- Umbral para el semaforo del KPI "margen bruto %" (verde >= objetivo)
  ADD COLUMN margen_objetivo_pct DECIMAL(5,2) NOT NULL DEFAULT 25.00 AFTER visibilidad,
  -- Dias tipicos entre pedir al proveedor y tener la mercaderia en almacen
  -- (para "reposicion sugerida"). Se puede afinar por producto.
  ADD COLUMN dias_reposicion INT NOT NULL DEFAULT 30 AFTER margen_objetivo_pct;

ALTER TABLE producto
  ADD COLUMN dias_reposicion INT NULL AFTER stock_minimo;   -- NULL = usar el de la empresa

-- ---------- Costos de importacion (landed cost) ----------
-- Los importes de compra siguen siempre en Bs (costo_unit, total). Si el
-- proveedor cotiza en otra moneda, la app convierte con tipo_cambio antes de
-- guardar y deja constancia del valor original en total_moneda.
ALTER TABLE compra
  ADD COLUMN moneda CHAR(3) NOT NULL DEFAULT 'BOB' AFTER total,
  ADD COLUMN tipo_cambio DECIMAL(10,4) NOT NULL DEFAULT 1.0000 AFTER moneda,
  ADD COLUMN total_moneda DECIMAL(14,2) NULL AFTER tipo_cambio,          -- FOB en la moneda original
  -- JSON [{"concepto":"Flete internacional","monto":1200.00}, ...] en Bs.
  -- Nota: el IVA de importacion normalmente es credito fiscal, no costo.
  ADD COLUMN costos_adicionales TEXT NULL AFTER total_moneda,
  ADD COLUMN total_costos DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER costos_adicionales,
  ADD COLUMN total_landed DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER total_costos;  -- total + total_costos

-- Costo unitario real: costo_unit prorrateado con los costos adicionales
-- (por valor: cada item absorbe costos en proporcion a su importe).
ALTER TABLE compra_detalle
  ADD COLUMN costo_landed_unit DECIMAL(14,4) NULL AFTER costo_unit;

-- Datos historicos: sin costos adicionales, landed = costo de compra.
UPDATE compra SET total_landed = total WHERE total_landed = 0;
UPDATE compra_detalle SET costo_landed_unit = costo_unit WHERE costo_landed_unit IS NULL;
