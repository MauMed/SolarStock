-- =====================================================================
-- V6: modulo de proformas (cotizaciones) + permisos faltantes
-- =====================================================================
-- Reglas de negocio acordadas:
--   * La proforma NO reserva stock. Al crearla o convertirla el sistema
--     solo advierte si el stock disponible es menor a lo cotizado.
--   * Validez por defecto configurable por empresa (15 dias inicial).
--     Cada proforma guarda su propia fecha limite (valida_hasta).
--   * Se puede enviar por correo (mail() nativo, igual que el reset de
--     contrasena). Se registra a que direccion y cuando se envio.
--   * Convertir a venta crea la venta con Inventario::crearVenta() y
--     enlaza venta_id; una proforma solo se convierte una vez.
--
-- Ciclo de estados:
--   BORRADOR -> ENVIADA -> ACEPTADA -> CONVERTIDA
--       |          |           |
--       +----------+-----------+--> VENCIDA (por fecha, la calcula el sistema)
--       +----------+-----------+--> ANULADA (manual)
-- =====================================================================
USE inventario_sin;

-- ------------- Configuracion por empresa -------------
ALTER TABLE empresa
  ADD COLUMN proforma_validez_dias INT NOT NULL DEFAULT 15 AFTER facturacion_activa,
  ADD COLUMN proforma_condiciones TEXT NULL AFTER proforma_validez_dias;
-- proforma_condiciones: texto al pie del documento (forma de pago, plazo de
-- entrega, "precios en Bs. con IVA incluido", etc.). NULL usa un texto generico.

-- --------------------- Proformas ---------------------
CREATE TABLE proforma (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  empresa_id INT NOT NULL,
  sucursal_id INT NOT NULL,
  almacen_id INT NOT NULL,                 -- almacen contra el que se cotiza y del que saldra la venta
  numero INT NOT NULL,                     -- correlativo por empresa (PRO-000001)
  cliente_id INT NULL,                     -- cliente registrado (opcional)
  cliente_nombre VARCHAR(200) NULL,        -- snapshot / cliente no registrado
  cliente_documento VARCHAR(30) NULL,
  cliente_email VARCHAR(150) NULL,
  cliente_telefono VARCHAR(30) NULL,
  subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
  descuento DECIMAL(14,2) NOT NULL DEFAULT 0,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  validez_dias INT NOT NULL DEFAULT 15,
  valida_hasta DATE NOT NULL,
  estado ENUM('BORRADOR','ENVIADA','ACEPTADA','CONVERTIDA','VENCIDA','ANULADA')
         NOT NULL DEFAULT 'BORRADOR',
  observaciones TEXT NULL,                 -- notas internas o visibles (se imprimen)
  condiciones TEXT NULL,                   -- copia de empresa.proforma_condiciones al crear (editable)
  venta_id BIGINT NULL,                    -- se llena al convertir
  enviada_email VARCHAR(150) NULL,
  enviada_en DATETIME NULL,
  usuario_id INT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_proforma_numero (empresa_id, numero),
  KEY ix_proforma_estado (empresa_id, estado, valida_hasta),
  KEY ix_proforma_cliente (cliente_id),
  FOREIGN KEY (empresa_id) REFERENCES empresa(id),
  FOREIGN KEY (sucursal_id) REFERENCES sucursal(id),
  FOREIGN KEY (almacen_id) REFERENCES almacen(id),
  FOREIGN KEY (cliente_id) REFERENCES cliente(id) ON DELETE SET NULL,
  FOREIGN KEY (venta_id) REFERENCES venta(id) ON DELETE SET NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE proforma_detalle (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  proforma_id BIGINT NOT NULL,
  producto_id INT NOT NULL,
  descripcion VARCHAR(255) NOT NULL,       -- snapshot del nombre (editable en la cotizacion)
  cantidad DECIMAL(14,3) NOT NULL,
  precio_unit DECIMAL(14,4) NOT NULL,
  descuento DECIMAL(14,2) NOT NULL DEFAULT 0,
  orden SMALLINT NOT NULL DEFAULT 0,       -- orden de impresion
  FOREIGN KEY (proforma_id) REFERENCES proforma(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES producto(id)
) ENGINE=InnoDB;

-- ---------------------- Permisos ----------------------
INSERT IGNORE INTO permiso (clave, modulo, descripcion) VALUES
('proformas.ver',       'Proformas', 'Ver proformas / cotizaciones'),
('proformas.crear',     'Proformas', 'Crear, editar, enviar y anular proformas'),
('proformas.convertir', 'Proformas', 'Convertir una proforma en venta');

-- Permisos que el codigo (Core\Auth::POR_ROL, router) usa desde v2/v4 pero
-- que ninguna migracion insertaba. Idempotente: no falla si ya existen.
INSERT IGNORE INTO permiso (clave, modulo, descripcion) VALUES
('almacenes.gestionar', 'Almacenes',   'Crear sucursales y almacenes'),
('pagos.ver',           'Pagos',       'Ver cuentas por cobrar y por pagar'),
('pagos.gestionar',     'Pagos',       'Marcar ventas y compras como pagadas');
