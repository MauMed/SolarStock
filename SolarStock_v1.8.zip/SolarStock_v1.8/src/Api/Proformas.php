<?php
namespace Api;

use Core\DB;

/**
 * Proformas / cotizaciones (tablas proforma y proforma_detalle, upgrade_v6).
 *
 * Reglas de negocio:
 *  - No reserva stock: al crear o convertir solo se advierte si el stock
 *    disponible del almacen es menor a lo cotizado.
 *  - Validez: empresa.proforma_validez_dias por defecto; cada proforma
 *    guarda su valida_hasta. VENCIDA la calcula el sistema al listar/leer.
 *  - Estados: BORRADOR -> ENVIADA -> ACEPTADA -> CONVERTIDA
 *                 |          |           |
 *                 +----------+-----------+--> VENCIDA | ANULADA
 *  - Convertir crea la venta con Inventario::crearVenta() (atomica) y
 *    enlaza venta_id; una proforma se convierte una sola vez.
 *  - Enviar por correo usa mail() nativo (como el reset de contrasena) y
 *    registra enviada_email / enviada_en.
 *
 * Endpoints (router):
 *  GET    /proformas                 listar (filtros: estado, q, desde, hasta)
 *  POST   /proformas                 crear
 *  GET    /proformas/{id}            detalle con items
 *  PUT    /proformas/{id}            editar (solo BORRADOR / ENVIADA)
 *  PUT    /proformas/{id}/estado     ENVIADA | ACEPTADA | ANULADA
 *  POST   /proformas/{id}/convertir  -> venta (+ factura opcional)
 *  POST   /proformas/{id}/enviar     correo al cliente
 */
class Proformas
{
    public const ESTADOS = ['BORRADOR', 'ENVIADA', 'ACEPTADA', 'CONVERTIDA', 'VENCIDA', 'ANULADA'];

    /** Transiciones manuales permitidas (destino => origenes validos). */
    public const TRANSICIONES = [
        'ENVIADA'  => ['BORRADOR'],
        'ACEPTADA' => ['BORRADOR', 'ENVIADA'],
        'ANULADA'  => ['BORRADOR', 'ENVIADA', 'ACEPTADA', 'VENCIDA'],
        'BORRADOR' => ['VENCIDA'],           // reactivar: renueva valida_hasta
    ];

    /** Estados desde los que se puede editar o convertir. */
    private const ABIERTOS = ['BORRADOR', 'ENVIADA', 'ACEPTADA'];

    // ------------------------------------------------------------------
    //  Lectura
    // ------------------------------------------------------------------

    /**
     * Marca como VENCIDA lo que paso de fecha. Solo BORRADOR y ENVIADA:
     * una proforma ACEPTADA sigue viva hasta convertirse o anularse.
     */
    public static function marcarVencidas(int $eid): void
    {
        DB::q('UPDATE proforma SET estado = "VENCIDA" WHERE empresa_id = ?
               AND estado IN ("BORRADOR","ENVIADA") AND valida_hasta < CURDATE()', [$eid]);
    }

    public static function listar(int $eid, array $filtros = []): array
    {
        self::marcarVencidas($eid);
        $w = ['p.empresa_id = ?']; $par = [$eid];
        if (!empty($filtros['estado']) && in_array($filtros['estado'], self::ESTADOS, true)) {
            $w[] = 'p.estado = ?'; $par[] = $filtros['estado'];
        }
        if (!empty($filtros['q'])) {
            $q = '%' . $filtros['q'] . '%';
            $w[] = '(COALESCE(c.razon_social, p.cliente_nombre, "") LIKE ? OR p.cliente_documento LIKE ? OR p.numero = ?)';
            array_push($par, $q, $q, (int)$filtros['q']);
        }
        if (!empty($filtros['desde'])) { $w[] = 'p.creado_en >= ?'; $par[] = $filtros['desde']; }
        if (!empty($filtros['hasta'])) { $w[] = 'p.creado_en <= ?'; $par[] = $filtros['hasta'] . ' 23:59:59'; }
        $lim = min(500, max(1, (int)($filtros['limit'] ?? 200)));
        return DB::q('SELECT p.id, p.numero, p.estado, p.total, p.valida_hasta, p.creado_en, p.venta_id,
                        p.enviada_en, COALESCE(c.razon_social, p.cliente_nombre, "S/N") cliente,
                        COALESCE(c.num_documento, p.cliente_documento) documento,
                        (SELECT COUNT(*) FROM proforma_detalle d WHERE d.proforma_id = p.id) n_items,
                        us.nombre usuario, DATEDIFF(p.valida_hasta, CURDATE()) dias_restantes
                      FROM proforma p LEFT JOIN cliente c ON c.id = p.cliente_id
                      LEFT JOIN usuario us ON us.id = p.usuario_id
                      WHERE ' . implode(' AND ', $w) . ' ORDER BY p.id DESC LIMIT ' . $lim, $par)->fetchAll();
    }

    public static function obtener(int $eid, int $id): array
    {
        self::marcarVencidas($eid);
        $p = DB::q('SELECT p.*, COALESCE(c.razon_social, p.cliente_nombre) cliente,
                      COALESCE(c.num_documento, p.cliente_documento) documento,
                      c.tipo_doc_sin, c.complemento, COALESCE(c.email, p.cliente_email) email,
                      COALESCE(c.telefono, p.cliente_telefono) telefono,
                      a.nombre almacen, s.nombre sucursal, us.nombre usuario,
                      DATEDIFF(p.valida_hasta, CURDATE()) dias_restantes
                    FROM proforma p LEFT JOIN cliente c ON c.id = p.cliente_id
                    JOIN almacen a ON a.id = p.almacen_id JOIN sucursal s ON s.id = p.sucursal_id
                    LEFT JOIN usuario us ON us.id = p.usuario_id
                    WHERE p.id = ? AND p.empresa_id = ?', [$id, $eid])->fetch()
            ?: throw new \RuntimeException('Proforma no encontrada');
        // Items con el stock actual del almacen: la proforma no reserva, solo advierte
        $p['items'] = DB::q('SELECT d.id, d.producto_id, d.descripcion, d.cantidad, d.precio_unit, d.descuento, d.orden,
                               pr.codigo_interno codigo, pr.nombre producto, pr.precio_venta precio_lista,
                               COALESCE(st.cantidad, 0) stock_disponible,
                               (COALESCE(st.cantidad, 0) < d.cantidad) stock_insuficiente,
                               ROUND(d.cantidad * d.precio_unit - d.descuento, 2) subtotal
                             FROM proforma_detalle d JOIN producto pr ON pr.id = d.producto_id
                             LEFT JOIN stock st ON st.producto_id = d.producto_id AND st.almacen_id = ?
                             WHERE d.proforma_id = ? ORDER BY d.orden, d.id', [$p['almacen_id'], $id])->fetchAll();
        $p['advertencias'] = array_values(array_map(
            fn($i) => "Stock insuficiente: {$i['descripcion']} (disponible {$i['stock_disponible']}, cotizado {$i['cantidad']})",
            array_filter($p['items'], fn($i) => (int)$i['stock_insuficiente'] === 1)));
        $p['venta'] = $p['venta_id']
            ? DB::q('SELECT v.id, v.total, v.fecha, v.estado,
                       (SELECT numero_factura FROM factura f WHERE f.venta_id = v.id AND f.estado != "ANULADA" LIMIT 1) numero_factura
                     FROM venta v WHERE v.id = ?', [$p['venta_id']])->fetch() ?: null
            : null;
        $p['puede_editar'] = in_array($p['estado'], ['BORRADOR', 'ENVIADA'], true);
        $p['puede_convertir'] = in_array($p['estado'], self::ABIERTOS, true);
        return $p;
    }

    // ------------------------------------------------------------------
    //  Escritura
    // ------------------------------------------------------------------

    /** Normaliza y valida los items (productos activos de la empresa). */
    private static function normalizarItems(int $eid, array $items): array
    {
        if (!$items) throw new \RuntimeException('La proforma no tiene items');
        $norm = []; $orden = 0;
        foreach ($items as $it) {
            $pid = (int)($it['producto_id'] ?? 0);
            $cant = (float)($it['cantidad'] ?? 0);
            if ($pid <= 0 || $cant <= 0) throw new \RuntimeException('Item invalido: producto o cantidad');
            $pr = DB::q('SELECT id, nombre, precio_venta FROM producto WHERE id = ? AND empresa_id = ? AND activo = 1', [$pid, $eid])->fetch()
                ?: throw new \RuntimeException("Producto $pid no existe o esta inactivo");
            $norm[] = [
                'producto_id' => $pid,
                'descripcion' => mb_substr(trim((string)($it['descripcion'] ?? '')) ?: $pr['nombre'], 0, 255),
                'cantidad' => $cant,
                'precio_unit' => isset($it['precio_unit']) && $it['precio_unit'] !== '' ? (float)$it['precio_unit'] : (float)$pr['precio_venta'],
                'descuento' => (float)($it['descuento'] ?? 0),
                'orden' => $orden++,
            ];
        }
        return $norm;
    }

    private static function totales(array $norm, float $descGlobal): array
    {
        $sub = 0;
        foreach ($norm as $it) $sub += $it['cantidad'] * $it['precio_unit'] - $it['descuento'];
        return [round($sub, 2), round($descGlobal, 2), round($sub - $descGlobal, 2)];
    }

    /** Datos de cliente para la cabecera (snapshot) a partir de cliente_id o campos libres. */
    private static function snapshotCliente(int $eid, array $in, ?int $clienteId): array
    {
        if ($clienteId) {
            $c = DB::q('SELECT razon_social, num_documento, email, telefono FROM cliente WHERE id = ?', [$clienteId])->fetch();
            return [$c['razon_social'], $c['num_documento'], $in['cliente_email'] ?? $c['email'], $in['cliente_telefono'] ?? $c['telefono']];
        }
        return [mb_substr(trim((string)($in['cliente_nombre'] ?? '')), 0, 200) ?: null,
                mb_substr(trim((string)($in['cliente_documento'] ?? '')), 0, 30) ?: null,
                trim((string)($in['cliente_email'] ?? '')) ?: null,
                trim((string)($in['cliente_telefono'] ?? '')) ?: null];
    }

    public static function crear(array $u, array $in): array
    {
        $eid = (int)$u['empresa_id'];
        $alm = Inventario::almacenDeEmpresa($eid, (int)($in['almacen_id'] ?? 0));
        $emp = DB::q('SELECT proforma_validez_dias, proforma_condiciones FROM empresa WHERE id = ?', [$eid])->fetch();
        $norm = self::normalizarItems($eid, $in['items'] ?? []);
        [$sub, $desc, $total] = self::totales($norm, (float)($in['descuento'] ?? 0));
        $validez = max(1, (int)($in['validez_dias'] ?? $emp['proforma_validez_dias']));
        $clienteId = Inventario::resolverCliente($eid, $in);
        [$cNom, $cDoc, $cMail, $cTel] = self::snapshotCliente($eid, $in, $clienteId);

        $id = DB::tx(function () use ($u, $in, $eid, $alm, $emp, $norm, $sub, $desc, $total, $validez, $clienteId, $cNom, $cDoc, $cMail, $cTel) {
            // Correlativo por empresa con lock: dos cajas no obtienen el mismo numero
            $n = (int)DB::q('SELECT COALESCE(MAX(numero), 0) + 1 n FROM proforma WHERE empresa_id = ? FOR UPDATE', [$eid])->fetch()['n'];
            DB::q('INSERT INTO proforma (empresa_id, sucursal_id, almacen_id, numero, cliente_id, cliente_nombre,
                     cliente_documento, cliente_email, cliente_telefono, subtotal, descuento, total,
                     validez_dias, valida_hasta, estado, observaciones, condiciones, usuario_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, DATE_ADD(CURDATE(), INTERVAL ? DAY), "BORRADOR", ?, ?, ?)',
                  [$eid, $alm['sucursal_id'], $alm['id'], $n, $clienteId, $cNom, $cDoc, $cMail, $cTel,
                   $sub, $desc, $total, $validez, $validez,
                   $in['observaciones'] ?? null, $in['condiciones'] ?? $emp['proforma_condiciones'], $u['id'] ?? null]);
            $id = DB::insertId();
            self::guardarItems($id, $norm);
            return $id;
        });
        return self::obtener($eid, $id);
    }

    private static function guardarItems(int $id, array $norm): void
    {
        DB::q('DELETE FROM proforma_detalle WHERE proforma_id = ?', [$id]);
        foreach ($norm as $it) {
            DB::q('INSERT INTO proforma_detalle (proforma_id, producto_id, descripcion, cantidad, precio_unit, descuento, orden)
                   VALUES (?,?,?,?,?,?,?)',
                  [$id, $it['producto_id'], $it['descripcion'], $it['cantidad'], $it['precio_unit'], $it['descuento'], $it['orden']]);
        }
    }

    private static function cargar(int $eid, int $id): array
    {
        return DB::q('SELECT * FROM proforma WHERE id = ? AND empresa_id = ?', [$id, $eid])->fetch()
            ?: throw new \RuntimeException('Proforma no encontrada');
    }

    public static function actualizar(array $u, int $id, array $in): array
    {
        $eid = (int)$u['empresa_id'];
        self::marcarVencidas($eid);
        $p = self::cargar($eid, $id);
        if (!in_array($p['estado'], ['BORRADOR', 'ENVIADA'], true)) {
            throw new \RuntimeException("No se puede editar una proforma {$p['estado']}");
        }
        $alm = Inventario::almacenDeEmpresa($eid, (int)($in['almacen_id'] ?? $p['almacen_id']));
        $norm = isset($in['items']) ? self::normalizarItems($eid, $in['items']) : null;
        if ($norm === null) {
            // Sin items en la peticion: se conservan los actuales
            $norm = array_map(fn($d) => ['producto_id' => (int)$d['producto_id'], 'descripcion' => $d['descripcion'],
                'cantidad' => (float)$d['cantidad'], 'precio_unit' => (float)$d['precio_unit'],
                'descuento' => (float)$d['descuento'], 'orden' => (int)$d['orden']],
                DB::q('SELECT * FROM proforma_detalle WHERE proforma_id = ? ORDER BY orden, id', [$id])->fetchAll());
        }
        [$sub, $desc, $total] = self::totales($norm, (float)($in['descuento'] ?? $p['descuento']));
        $clienteId = array_key_exists('cliente_id', $in) || isset($in['cliente'])
            ? Inventario::resolverCliente($eid, $in) : ($p['cliente_id'] ? (int)$p['cliente_id'] : null);
        if ($clienteId || isset($in['cliente_nombre'])) {
            [$cNom, $cDoc, $cMail, $cTel] = self::snapshotCliente($eid, $in, $clienteId);
        } else {
            [$cNom, $cDoc, $cMail, $cTel] = [$p['cliente_nombre'], $p['cliente_documento'],
                $in['cliente_email'] ?? $p['cliente_email'], $in['cliente_telefono'] ?? $p['cliente_telefono']];
        }
        $validez = isset($in['validez_dias']) ? max(1, (int)$in['validez_dias']) : null;

        DB::tx(function () use ($id, $in, $p, $alm, $norm, $sub, $desc, $total, $clienteId, $cNom, $cDoc, $cMail, $cTel, $validez) {
            DB::q('UPDATE proforma SET sucursal_id = ?, almacen_id = ?, cliente_id = ?, cliente_nombre = ?,
                     cliente_documento = ?, cliente_email = ?, cliente_telefono = ?, subtotal = ?, descuento = ?, total = ?,
                     observaciones = ?, condiciones = ?' .
                     ($validez ? ', validez_dias = ?, valida_hasta = DATE_ADD(CURDATE(), INTERVAL ? DAY)' : '') . '
                   WHERE id = ?',
                  array_merge([$alm['sucursal_id'], $alm['id'], $clienteId, $cNom, $cDoc, $cMail, $cTel, $sub, $desc, $total,
                     $in['observaciones'] ?? $p['observaciones'], $in['condiciones'] ?? $p['condiciones']],
                     $validez ? [$validez, $validez] : [], [$id]));
            self::guardarItems($id, $norm);
        });
        return self::obtener((int)$u['empresa_id'], $id);
    }

    public static function cambiarEstado(array $u, int $id, string $estado): array
    {
        $eid = (int)$u['empresa_id'];
        self::marcarVencidas($eid);
        $p = self::cargar($eid, $id);
        if (!isset(self::TRANSICIONES[$estado])) throw new \RuntimeException("Estado no permitido: $estado");
        if (!in_array($p['estado'], self::TRANSICIONES[$estado], true)) {
            throw new \RuntimeException("No se puede pasar de {$p['estado']} a $estado");
        }
        if ($estado === 'BORRADOR') {   // reactivar una vencida: nueva vigencia desde hoy
            DB::q('UPDATE proforma SET estado = "BORRADOR", valida_hasta = DATE_ADD(CURDATE(), INTERVAL validez_dias DAY) WHERE id = ?', [$id]);
        } else {
            DB::q('UPDATE proforma SET estado = ? WHERE id = ?', [$estado, $id]);
        }
        return self::obtener($eid, $id);
    }

    /**
     * Convierte en venta (descuenta stock, atomico). Opciones en $in:
     *  almacen_id (por defecto el de la proforma), facturar (bool), metodo_pago_sin, origen.
     * Si el stock no alcanza, crearVenta() falla y la proforma queda intacta.
     */
    public static function convertir(array $u, int $id, array $in): array
    {
        $eid = (int)$u['empresa_id'];
        self::marcarVencidas($eid);
        $p = self::cargar($eid, $id);
        if (!in_array($p['estado'], self::ABIERTOS, true)) {
            throw new \RuntimeException("La proforma esta {$p['estado']}; no se puede convertir");
        }
        $items = DB::q('SELECT producto_id, cantidad, precio_unit, descuento FROM proforma_detalle
                        WHERE proforma_id = ? ORDER BY orden, id', [$id])->fetchAll();
        $ventaIn = [
            'almacen_id' => (int)($in['almacen_id'] ?? $p['almacen_id']),
            'cliente_id' => $p['cliente_id'],
            'descuento' => (float)$p['descuento'],
            'metodo_pago_sin' => $in['metodo_pago_sin'] ?? 1,
            'origen' => $in['origen'] ?? 'INV',
            'items' => $items,
        ];
        $venta = DB::tx(function () use ($u, $id, $ventaIn) {
            // Lock de la fila: dos usuarios no convierten la misma proforma a la vez
            $st = DB::q('SELECT estado FROM proforma WHERE id = ? FOR UPDATE', [$id])->fetch();
            if (!in_array($st['estado'], self::ABIERTOS, true)) throw new \RuntimeException('La proforma ya fue convertida o cerrada');
            $venta = Inventario::crearVenta($u, $ventaIn);
            DB::q('UPDATE proforma SET estado = "CONVERTIDA", venta_id = ? WHERE id = ?', [$venta['id'], $id]);
            return $venta;
        });
        $out = ['venta' => $venta, 'factura' => null];
        if (!empty($in['facturar'])) {
            // Fuera de la transaccion: la llamada SOAP puede tardar o fallar sin deshacer la venta
            $emp = DB::q('SELECT facturacion_activa FROM empresa WHERE id = ?', [$eid])->fetch();
            if (!$emp['facturacion_activa']) throw new \RuntimeException('Venta creada, pero el modulo de facturacion esta desactivado');
            $fac = \Siat\Facturador::paraVenta((int)$venta['id'], $eid, (int)($in['siat_config_id'] ?? 0) ?: null);
            $out['factura'] = $fac->emitirDesdeVenta((int)$venta['id']);
        }
        $out['proforma'] = self::obtener($eid, $id);
        return $out;
    }

    /**
     * Envia la proforma por correo (texto plano, mail() nativo). Si no hay
     * mail() configurado en el hosting devuelve correo_enviado=false y el
     * texto, para copiarlo y mandarlo por otro canal.
     */
    public static function enviarCorreo(array $u, int $id, ?string $email = null): array
    {
        $eid = (int)$u['empresa_id'];
        $p = self::obtener($eid, $id);
        if (in_array($p['estado'], ['CONVERTIDA', 'ANULADA'], true)) {
            throw new \RuntimeException("La proforma esta {$p['estado']}; no se envia");
        }
        $email = trim((string)($email ?: $p['email'] ?: ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('Correo del cliente invalido o ausente');

        $cfg = require dirname(__DIR__, 2) . '/config/config.php';
        $emp = DB::q('SELECT COALESCE(nombre_comercial, razon_social) marca, razon_social, nit, telefono, direccion FROM empresa WHERE id = ?', [$eid])->fetch();
        $nro = 'PRO-' . str_pad((string)$p['numero'], 6, '0', STR_PAD_LEFT);
        $lineas = [];
        foreach ($p['items'] as $i) {
            $lineas[] = sprintf('%-8s %-40s %10s x %10s = %12s', $i['codigo'], mb_substr($i['descripcion'], 0, 40),
                number_format((float)$i['cantidad'], 2), number_format((float)$i['precio_unit'], 2), number_format((float)$i['subtotal'], 2));
        }
        $cuerpo = "{$emp['marca']}" . ($emp['nit'] ? " · NIT {$emp['nit']}" : '') . "\n"
                . ($emp['direccion'] ? $emp['direccion'] . "\n" : '') . ($emp['telefono'] ? 'Tel. ' . $emp['telefono'] . "\n" : '')
                . "\nPROFORMA $nro\nFecha: " . substr($p['creado_en'], 0, 10) . "   Valida hasta: {$p['valida_hasta']}\n"
                . 'Cliente: ' . ($p['cliente'] ?: 'S/N') . ($p['documento'] ? " · Doc {$p['documento']}" : '') . "\n\n"
                . implode("\n", $lineas) . "\n\n"
                . sprintf('%64s %12s', 'Subtotal Bs', number_format((float)$p['subtotal'], 2)) . "\n"
                . ((float)$p['descuento'] > 0 ? sprintf('%64s %12s', 'Descuento Bs', number_format((float)$p['descuento'], 2)) . "\n" : '')
                . sprintf('%64s %12s', 'TOTAL Bs', number_format((float)$p['total'], 2)) . "\n\n"
                . ($p['observaciones'] ? "Observaciones: {$p['observaciones']}\n\n" : '')
                . ($p['condiciones'] ? "Condiciones: {$p['condiciones']}\n\n" : '')
                . "Esta proforma no es una factura ni reserva mercaderia.\n";
        $asunto = "Proforma $nro - {$emp['marca']}";
        $cab = 'From: ' . $cfg['mail']['from_nombre'] . ' <' . $cfg['mail']['from'] . ">\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n";
        $enviado = @mail($email, $asunto, $cuerpo, $cab);
        if ($enviado) {
            DB::q('UPDATE proforma SET enviada_email = ?, enviada_en = NOW(),
                     estado = IF(estado = "BORRADOR", "ENVIADA", estado) WHERE id = ?', [$email, $id]);
        }
        return ['correo_enviado' => (bool)$enviado, 'email' => $email, 'asunto' => $asunto, 'texto' => $cuerpo,
                'proforma' => self::obtener($eid, $id)];
    }
}
