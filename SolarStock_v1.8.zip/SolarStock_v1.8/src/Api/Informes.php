<?php
namespace Api;

use Core\DB;

/**
 * Informes a nivel de producto y resumen contable.
 *
 * Cada informe es una consulta parametrizada por empresa y rango de fechas
 * que devuelve filas planas (listas para tabla o CSV). El router solo
 * autentica, arma el rango y despacha aqui.
 *
 * Para agregar un informe: sumar la clave a TIPOS y un case en generar().
 */
class Informes
{
    /**
     * Catalogo de informes: clave => [nombre, grupo, descripcion, usa_rango].
     * usa_rango=false: el informe es una foto del momento (stock) o define su
     * propio periodo. Alimenta el selector de la app y la pantalla de
     * interruptores (Marca > Informes y KPIs visibles).
     */
    public const CATALOGO = [
        'resumen'             => ['Resumen contable (KPIs, graficos)', 'Ventas', 'Bloque superior de la pantalla Informes: 15 KPIs y graficos del periodo', true],
        'ventas'              => ['Ventas por periodo', 'Ventas', 'Detalle de cada linea vendida', true],
        'ventas_cliente'      => ['Ventas por cliente', 'Ventas', 'Monto, compras, ticket promedio, margen y dias sin comprar', true],
        'ventas_vendedor'     => ['Ventas por vendedor', 'Ventas', 'Monto, ventas y margen por usuario (base para comisiones)', true],
        'ventas_categoria'    => ['Ventas por categoria', 'Ventas', 'Que lineas de producto crecen y cuales no', true],
        'comparativo_mensual' => ['Comparativo mensual (12 meses)', 'Ventas', 'Ventas, compras y margen mes a mes con variacion %', false],
        'ventas_horario'      => ['Ventas por hora y dia de semana', 'Ventas', 'Para dimensionar turnos de caja', true],
        'margen'              => ['Ventas con margen obtenido', 'Ventas', 'Margen por linea vendida', true],
        'inventario'          => ['Inventario valorizado', 'Stock', 'Stock actual a costo y a precio de venta', false],
        'rotacion'            => ['Rotacion e inventario inmovilizado', 'Stock', 'Vendido 30/90/180 dias, dias de inventario y valor sin movimiento', false],
        'reposicion'          => ['Reposicion sugerida', 'Stock', 'Que pedir y cuanto, segun venta diaria, minimo y dias de reposicion', false],
        'quiebres'            => ['Quiebres de stock', 'Stock', 'Dias en cero por producto y venta perdida estimada', true],
        'kardex'              => ['Kardex de movimientos', 'Stock', 'Todos los movimientos (incluye traspasos)', true],
        'compras'             => ['Compras por periodo', 'Compras e importaciones', 'Detalle de cada linea comprada', true],
        'compras_proveedor'   => ['Compras por proveedor', 'Compras e importaciones', 'Monto, frecuencia, costos de importacion y ultima compra', true],
        'evolucion_costos'    => ['Evolucion del costo por producto', 'Compras e importaciones', 'Costo de compra y costo landed de cada compra, con variacion', true],
        'importaciones'       => ['Costo de importacion (landed cost)', 'Compras e importaciones', 'FOB, costos adicionales, total landed y factor por compra', true],
        'facturas'            => ['Facturas emitidas (SIAT)', 'Tributario y finanzas', 'Estado de cada factura', true],
        'libro_ventas'        => ['Libro de ventas IVA', 'Tributario y finanzas', 'Formato del SIN a partir de las facturas emitidas', true],
        'libro_compras'       => ['Libro de compras IVA', 'Tributario y finanzas', 'Formato del SIN a partir de las facturas recibidas', true],
        'cxc'                 => ['Cuentas por cobrar', 'Tributario y finanzas', 'Ventas pendientes de pago y mora', true],
        'cxp'                 => ['Cuentas por pagar', 'Tributario y finanzas', 'Compras pendientes de pago y mora', true],
        'aging'               => ['Antiguedad de cartera (aging)', 'Tributario y finanzas', 'CxC y CxP por tercero en tramos 0-30 / 31-60 / 61-90 / +90 dias', false],
        'proformas'           => ['Embudo de proformas', 'Proformas', 'Emitidas, aceptadas, convertidas, vencidas; tasa de conversion por vendedor', true],
    ];
    public const TIPOS = ['ventas', 'compras', 'inventario', 'kardex', 'facturas', 'margen', 'cxc', 'cxp',
        'ventas_cliente', 'ventas_vendedor', 'ventas_categoria', 'comparativo_mensual', 'ventas_horario',
        'rotacion', 'reposicion', 'quiebres', 'compras_proveedor', 'evolucion_costos', 'importaciones',
        'libro_ventas', 'libro_compras', 'aging', 'proformas'];

    /** Lo oculto por la empresa: ['informes_ocultos' => [...], 'kpis_ocultos' => [...]]. */
    public static function visibilidad(int $eid): array
    {
        $raw = DB::q('SELECT visibilidad FROM empresa WHERE id = ?', [$eid])->fetch()['visibilidad'] ?? null;
        $v = $raw ? (json_decode($raw, true) ?: []) : [];
        return ['informes_ocultos' => array_values((array)($v['informes_ocultos'] ?? [])),
                'kpis_ocultos' => array_values((array)($v['kpis_ocultos'] ?? []))];
    }

    /** Catalogo con la marca visible/oculto de la empresa, para la app. */
    public static function catalogo(int $eid): array
    {
        $vis = self::visibilidad($eid);
        $out = [];
        foreach (self::CATALOGO as $k => [$nombre, $grupo, $desc, $rango]) {
            $out[] = ['clave' => $k, 'nombre' => $nombre, 'grupo' => $grupo, 'descripcion' => $desc,
                      'usa_rango' => $rango, 'visible' => !in_array($k, $vis['informes_ocultos'], true)];
        }
        return $out;
    }

    /** Rango [desde, hasta] a partir de ?desde=&hasta= (por defecto: mes en curso). */
    public static function rango(array $get): array
    {
        $desde = $get['desde'] ?? date('Y-m-01');
        $hasta = ($get['hasta'] ?? date('Y-m-d')) . ' 23:59:59';
        return [$desde, $hasta];
    }

    /** Resumen contable: 15 KPIs + serie ventas/compras + top margen. */
    public static function resumen(int $eid, string $desde, string $hasta): array
    {
        $ventas = DB::q('SELECT COUNT(DISTINCT v.id) n, COALESCE(SUM(vd.cantidad * vd.precio_unit - vd.descuento),0) total,
              COALESCE(SUM(vd.cantidad * p.precio_compra),0) cmv
            FROM venta v JOIN venta_detalle vd ON vd.venta_id = v.id
            JOIN producto p ON p.id = vd.producto_id
            WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"',
            [$eid, $desde, $hasta])->fetch();
        $compras = DB::q('SELECT COALESCE(SUM(total),0) t FROM compra
            WHERE empresa_id = ? AND fecha BETWEEN ? AND ? AND estado != "ANULADA"',
            [$eid, $desde, $hasta])->fetch()['t'];
        $inv = DB::q('SELECT COALESCE(SUM(st.cantidad * p.precio_compra),0) v FROM stock st
            JOIN producto p ON p.id = st.producto_id WHERE p.empresa_id = ? AND p.activo = 1',
            [$eid])->fetch()['v'];
        $facturado = DB::q('SELECT COALESCE(SUM(f.monto_total),0) t FROM factura f
            JOIN siat_config sc ON sc.id = f.siat_config_id JOIN sucursal su ON su.id = sc.sucursal_id
            WHERE su.empresa_id = ? AND f.fecha_emision BETWEEN ? AND ? AND f.estado = "VALIDA"',
            [$eid, $desde, $hasta])->fetch()['t'];
        $facRecibidas = DB::q('SELECT COALESCE(SUM(monto_total),0) t FROM factura_recibida
            WHERE empresa_id = ? AND (fecha_emision BETWEEN ? AND ? OR fecha_emision IS NULL)',
            [$eid, $desde, $hasta])->fetch()['t'];
        $margen = (float)$ventas['total'] - (float)$ventas['cmv'];
        return [
            'kpis' => [
                'ventas' => round((float)$ventas['total'], 2),
                'num_ventas' => (int)$ventas['n'],
                'ticket_promedio' => $ventas['n'] ? round($ventas['total'] / $ventas['n'], 2) : 0,
                'cmv' => round((float)$ventas['cmv'], 2),                       // costo de mercaderia vendida
                'margen_bruto' => round($margen, 2),
                'margen_pct' => $ventas['total'] > 0 ? round($margen / $ventas['total'] * 100, 1) : 0,
                'compras' => round((float)$compras, 2),
                'valor_inventario' => round((float)$inv, 2),                    // activo realizable
                'facturado_siat' => round((float)$facturado, 2),
                'iva_debito_estimado' => round($facturado * 0.13, 2),           // estimacion 13%
                'iva_credito_estimado' => round($facRecibidas * 0.13, 2),       // estimacion 13%
                'cuentas_por_cobrar' => (float)DB::q('SELECT COALESCE(SUM(total),0) t FROM venta
                    WHERE empresa_id = ? AND pagada = 0 AND estado = "COMPLETADA"', [$eid])->fetch()['t'],
                'cuentas_por_pagar' => (float)DB::q('SELECT COALESCE(SUM(total),0) t FROM compra
                    WHERE empresa_id = ? AND pagada = 0 AND estado != "ANULADA"', [$eid])->fetch()['t'],
                'mora_por_cobrar' => (float)DB::q('SELECT COALESCE(SUM(total),0) t FROM venta
                    WHERE empresa_id = ? AND pagada = 0 AND estado = "COMPLETADA"
                    AND fecha < DATE_SUB(NOW(), INTERVAL 30 DAY)', [$eid])->fetch()['t'],
                'mora_por_pagar' => (float)DB::q('SELECT COALESCE(SUM(total),0) t FROM compra
                WHERE empresa_id = ? AND pagada = 0 AND estado != "ANULADA"
                AND fecha < DATE_SUB(NOW(), INTERVAL 30 DAY)', [$eid])->fetch()['t'],
        ],
        'serie_ventas_compras' => DB::q('
            SELECT d, SUM(v) ventas, SUM(c) compras FROM (
              SELECT DATE(fecha) d, total v, 0 c FROM venta
                WHERE empresa_id = ? AND fecha BETWEEN ? AND ? AND estado = "COMPLETADA"
              UNION ALL
              SELECT DATE(fecha) d, 0 v, total c FROM compra
                WHERE empresa_id = ? AND fecha BETWEEN ? AND ? AND estado != "ANULADA"
            ) x GROUP BY d ORDER BY d', [$eid, $desde, $hasta, $eid, $desde, $hasta])->fetchAll(),
        'top_margen' => DB::q('SELECT p.nombre,
              ROUND(SUM(vd.cantidad * (vd.precio_unit - p.precio_compra)), 2) margen
            FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
            JOIN producto p ON p.id = vd.producto_id
            WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
            GROUP BY p.id ORDER BY margen DESC LIMIT 5', [$eid, $desde, $hasta])->fetchAll(),
        ];
    }

    /** Filas del informe $tipo. $filtros: producto_id (kardex). */
    public static function generar(string $tipo, int $eid, string $desde, string $hasta, array $filtros = []): array
    {
        if (!in_array($tipo, self::TIPOS, true)) throw new \RuntimeException("Informe desconocido: $tipo");
        $rows = [];
        switch ($tipo) {
            case 'ventas':
                $rows = DB::q('SELECT v.id venta, v.fecha, COALESCE(c.razon_social, "S/N") cliente,
                      p.codigo_interno codigo, p.nombre producto, vd.cantidad, vd.precio_unit,
                      ROUND(vd.cantidad * vd.precio_unit - vd.descuento, 2) total,
                      v.origen, v.estado,
                      (SELECT COUNT(*) FROM factura f WHERE f.venta_id = v.id AND f.estado != "ANULADA") facturada
                    FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                    JOIN producto p ON p.id = vd.producto_id
                    LEFT JOIN cliente c ON c.id = v.cliente_id
                    WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ?
                    ORDER BY v.fecha DESC', [$eid, $desde, $hasta])->fetchAll();
                break;
            case 'margen':
                // Ventas con margen obtenido: (precio venta - costo del producto) x cantidad
                $rows = DB::q('SELECT v.fecha, p.codigo_interno codigo, p.nombre producto,
                      vd.cantidad, vd.precio_unit, p.precio_compra costo_unit,
                      ROUND(vd.cantidad * vd.precio_unit, 2) venta_total,
                      ROUND(vd.cantidad * p.precio_compra, 2) costo_total,
                      ROUND(vd.cantidad * (vd.precio_unit - p.precio_compra), 2) margen,
                      IF(vd.precio_unit > 0,
                         ROUND((vd.precio_unit - p.precio_compra) / vd.precio_unit * 100, 1), 0) margen_pct
                    FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                    JOIN producto p ON p.id = vd.producto_id
                    WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                    ORDER BY margen DESC, v.fecha DESC, vd.id DESC', [$eid, $desde, $hasta])->fetchAll();
                break;
            case 'compras':
                $rows = DB::q('SELECT co.id compra, co.fecha, COALESCE(pr.razon_social, "S/N") proveedor,
                      co.nro_documento, p.codigo_interno codigo, p.nombre producto,
                      cd.cantidad, cd.costo_unit,
                      ROUND(cd.cantidad * cd.costo_unit, 2) total, co.estado
                    FROM compra_detalle cd JOIN compra co ON co.id = cd.compra_id
                    JOIN producto p ON p.id = cd.producto_id
                    LEFT JOIN proveedor pr ON pr.id = co.proveedor_id
                    WHERE co.empresa_id = ? AND co.fecha BETWEEN ? AND ?
                    ORDER BY co.fecha DESC', [$eid, $desde, $hasta])->fetchAll();
                break;
            case 'inventario':
                $rows = DB::q('SELECT p.codigo_interno, p.codigo_barras, p.nombre,
                      COALESCE(SUM(s.cantidad),0) stock, p.stock_minimo,
                  p.precio_compra, p.precio_venta,
                  ROUND(COALESCE(SUM(s.cantidad),0) * p.precio_compra, 2) valor_costo,
                  ROUND(COALESCE(SUM(s.cantidad),0) * p.precio_venta, 2) valor_venta
                FROM producto p LEFT JOIN stock s ON s.producto_id = p.id
                WHERE p.empresa_id = ? AND p.activo = 1
                GROUP BY p.id ORDER BY p.nombre', [$eid])->fetchAll();
            break;
        case 'kardex':
            $extra = !empty($filtros['producto_id']) ? ' AND m.producto_id = ' . (int)$filtros['producto_id'] : '';
            $rows = DB::q('SELECT m.fecha, p.codigo_interno codigo, p.nombre producto, m.tipo,
                  a.nombre almacen, m.cantidad, m.costo_unit, m.saldo_resultante,
                  m.referencia_tipo, COALESCE(us.nombre, "-") usuario
                FROM movimiento m JOIN producto p ON p.id = m.producto_id
                LEFT JOIN almacen a ON a.id = m.almacen_id
                LEFT JOIN usuario us ON us.id = m.usuario_id
                WHERE m.empresa_id = ? AND m.fecha BETWEEN ? AND ?' . $extra . '
                ORDER BY m.fecha DESC LIMIT 5000', [$eid, $desde, $hasta])->fetchAll();
            break;
        case 'cxc':
            $rows = DB::q('SELECT v.id venta, v.fecha, COALESCE(c.razon_social,"S/N") cliente,
                  v.total, v.origen, IF(v.pagada, "PAGADA", "PENDIENTE") estado_pago,
                  v.fecha_pago, DATEDIFF(COALESCE(v.fecha_pago, NOW()), v.fecha) dias,
                  IF(DATEDIFF(NOW(), v.fecha) > 30 AND v.pagada = 0, "SI", "NO") mora
                FROM venta v LEFT JOIN cliente c ON c.id = v.cliente_id
                WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                ORDER BY v.pagada, v.fecha', [$eid, $desde, $hasta])->fetchAll();
            break;
        case 'cxp':
            $rows = DB::q('SELECT co.id compra, co.fecha, COALESCE(pr.razon_social,"S/N") proveedor,
                  co.nro_documento, co.total, IF(co.pagada, "PAGADA", "PENDIENTE") estado_pago,
                  co.fecha_pago, DATEDIFF(COALESCE(co.fecha_pago, NOW()), co.fecha) dias,
                  IF(DATEDIFF(NOW(), co.fecha) > 30 AND co.pagada = 0, "SI", "NO") mora
                FROM compra co LEFT JOIN proveedor pr ON pr.id = co.proveedor_id
                WHERE co.empresa_id = ? AND co.fecha BETWEEN ? AND ? AND co.estado != "ANULADA"
                ORDER BY co.pagada, co.fecha', [$eid, $desde, $hasta])->fetchAll();
            break;
        case 'facturas':
            $rows = DB::q('SELECT f.numero_factura, f.cuf, f.fecha_emision, f.tipo_emision,
                  f.monto_total, f.estado, f.error_descripcion
                FROM factura f JOIN siat_config sc ON sc.id = f.siat_config_id
                JOIN sucursal su ON su.id = sc.sucursal_id
                WHERE su.empresa_id = ? AND f.fecha_emision BETWEEN ? AND ?
                ORDER BY f.fecha_emision DESC', [$eid, $desde, $hasta])->fetchAll();
            break;

            // ---------------- VENTAS AGRUPADAS ----------------
            case 'ventas_cliente':
            case 'ventas_vendedor':
            case 'ventas_categoria':
                $grp = ['ventas_cliente' => ['v.cliente_id', 'COALESCE(c.razon_social, "S/N") cliente, c.num_documento documento,', 'LEFT JOIN cliente c ON c.id = v.cliente_id'],
                        'ventas_vendedor' => ['v.usuario_id', 'COALESCE(us.nombre, "Sin usuario / API") vendedor,', 'LEFT JOIN usuario us ON us.id = v.usuario_id'],
                        'ventas_categoria' => ['p.categoria_id', 'COALESCE(ca.nombre, "Sin categoria") categoria,', 'LEFT JOIN categoria ca ON ca.id = p.categoria_id']][$tipo];
                $rows = DB::q('SELECT ' . $grp[1] . '
                          COUNT(DISTINCT v.id) ventas, SUM(vd.cantidad) unidades,
                          ROUND(SUM(vd.cantidad * vd.precio_unit - vd.descuento), 2) total,
                          ROUND(SUM(vd.cantidad * vd.precio_unit - vd.descuento) / COUNT(DISTINCT v.id), 2) ticket_promedio,
                          ROUND(SUM(vd.cantidad * (vd.precio_unit - p.precio_compra) - vd.descuento), 2) margen,
                          IF(SUM(vd.cantidad * vd.precio_unit - vd.descuento) > 0,
                             ROUND(SUM(vd.cantidad * (vd.precio_unit - p.precio_compra) - vd.descuento) / SUM(vd.cantidad * vd.precio_unit - vd.descuento) * 100, 1), 0) margen_pct,
                          MAX(v.fecha) ultima_venta, DATEDIFF(NOW(), MAX(v.fecha)) dias_sin_comprar
                        FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                        JOIN producto p ON p.id = vd.producto_id ' . $grp[2] . '
                        WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                        GROUP BY ' . $grp[0] . ' ORDER BY total DESC', [$eid, $desde, $hasta])->fetchAll();
                if ($tipo !== 'ventas_cliente') foreach ($rows as &$r) unset($r['dias_sin_comprar']);
                unset($r);
                break;

            case 'comparativo_mensual':
                // 12 meses terminando en el mes de $hasta (ignora $desde)
                $fin = new \DateTime(substr($hasta, 0, 10)); $fin->modify('last day of this month');
                $ini = (clone $fin)->modify('first day of this month')->modify('-11 months');
                $d0 = $ini->format('Y-m-d'); $d1 = $fin->format('Y-m-d 23:59:59');
                $v = DB::q('SELECT DATE_FORMAT(v.fecha, "%Y-%m") mes, COUNT(DISTINCT v.id) ventas,
                              ROUND(SUM(vd.cantidad * vd.precio_unit - vd.descuento), 2) total,
                              ROUND(SUM(vd.cantidad * (vd.precio_unit - p.precio_compra) - vd.descuento), 2) margen
                            FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id JOIN producto p ON p.id = vd.producto_id
                            WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                            GROUP BY mes', [$eid, $d0, $d1])->fetchAll();
                $c = DB::q('SELECT DATE_FORMAT(fecha, "%Y-%m") mes, ROUND(SUM(total_landed), 2) compras FROM compra
                            WHERE empresa_id = ? AND fecha BETWEEN ? AND ? AND estado != "ANULADA" GROUP BY mes', [$eid, $d0, $d1])->fetchAll();
                $vm = array_column($v, null, 'mes'); $cm = array_column($c, 'compras', 'mes');
                $prev = null;
                for ($m = clone $ini; $m <= $fin; $m->modify('+1 month')) {
                    $k = $m->format('Y-m'); $tot = (float)($vm[$k]['total'] ?? 0);
                    $rows[] = ['mes' => $k, 'ventas' => (int)($vm[$k]['ventas'] ?? 0), 'total' => $tot,
                        'variacion_pct' => $prev === null ? null : ($prev > 0 ? round(($tot - $prev) / $prev * 100, 1) : null),
                        'margen' => (float)($vm[$k]['margen'] ?? 0),
                        'margen_pct' => $tot > 0 ? round((float)($vm[$k]['margen'] ?? 0) / $tot * 100, 1) : 0,
                        'compras' => (float)($cm[$k] ?? 0)];
                    $prev = $tot;
                }
                break;

            case 'ventas_horario':
                $raw = DB::q('SELECT HOUR(fecha) hora, DAYOFWEEK(fecha) dow, COUNT(*) n, SUM(total) t FROM venta
                              WHERE empresa_id = ? AND fecha BETWEEN ? AND ? AND estado = "COMPLETADA"
                              GROUP BY hora, dow', [$eid, $desde, $hasta])->fetchAll();
                $dias = [2 => 'lun', 3 => 'mar', 4 => 'mie', 5 => 'jue', 6 => 'vie', 7 => 'sab', 1 => 'dom'];
                $grid = [];
                foreach ($raw as $r) { $grid[(int)$r['hora']][$dias[(int)$r['dow']]] = ['n' => (int)$r['n'], 't' => (float)$r['t']]; }
                ksort($grid);
                foreach ($grid as $h => $d) {
                    $row = ['hora' => sprintf('%02d:00', $h)]; $tn = 0; $tt = 0;
                    foreach ($dias as $nom) { $row[$nom] = $d[$nom]['t'] ?? 0; $tn += $d[$nom]['n'] ?? 0; $tt += $d[$nom]['t'] ?? 0; }
                    $row['ventas'] = $tn; $row['total'] = round($tt, 2);
                    $rows[] = $row;
                }
                break;

            // ---------------- STOCK ----------------
            case 'rotacion':
            case 'reposicion':
                $base = DB::q('SELECT p.id, p.codigo_interno codigo, p.nombre producto, COALESCE(ca.nombre, "") categoria,
                          COALESCE(SUM(s.cantidad), 0) stock, p.stock_minimo, p.precio_compra, p.precio_venta,
                          COALESCE(p.dias_reposicion, e.dias_reposicion) dias_reposicion,
                          (SELECT COALESCE(SUM(vd.cantidad), 0) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                             WHERE vd.producto_id = p.id AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 30 DAY)) vendido_30,
                          (SELECT COALESCE(SUM(vd.cantidad), 0) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                             WHERE vd.producto_id = p.id AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 90 DAY)) vendido_90,
                          (SELECT COALESCE(SUM(vd.cantidad), 0) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                             WHERE vd.producto_id = p.id AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 180 DAY)) vendido_180,
                          (SELECT MAX(v.fecha) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                             WHERE vd.producto_id = p.id AND v.estado = "COMPLETADA") ultima_venta
                        FROM producto p JOIN empresa e ON e.id = p.empresa_id
                        LEFT JOIN categoria ca ON ca.id = p.categoria_id
                        LEFT JOIN stock s ON s.producto_id = p.id
                        WHERE p.empresa_id = ? AND p.activo = 1 GROUP BY p.id ORDER BY p.nombre', [$eid])->fetchAll();
                foreach ($base as $r) {
                    $stock = (float)$r['stock']; $vd = (float)$r['vendido_90'] / 90;   // venta diaria
                    $diasInv = $vd > 0 ? (int)round($stock / $vd) : null;
                    if ($tipo === 'rotacion') {
                        $rows[] = ['codigo' => $r['codigo'], 'producto' => $r['producto'], 'categoria' => $r['categoria'],
                            'stock' => $stock, 'vendido_30' => (float)$r['vendido_30'], 'vendido_90' => (float)$r['vendido_90'],
                            'vendido_180' => (float)$r['vendido_180'], 'venta_diaria' => round($vd, 3),
                            'dias_inventario' => $diasInv, 'valor_costo' => round($stock * (float)$r['precio_compra'], 2),
                            'inmovilizado' => ($stock > 0 && (float)$r['vendido_90'] == 0) ? 'SI' : 'NO',
                            'ultima_venta' => $r['ultima_venta'] ? substr($r['ultima_venta'], 0, 10) : null];
                    } else {
                        $lead = (int)$r['dias_reposicion']; $min = (float)$r['stock_minimo'];
                        $demanda = $vd * $lead;                     // lo que se vende mientras llega el pedido
                        $punto = $demanda + $min;                   // punto de pedido
                        if ($stock > $punto) continue;              // todavia no toca pedir
                        $sugerido = max(0, (int)ceil($punto + $demanda - $stock));   // lead time + un ciclo mas + minimo
                        $rows[] = ['codigo' => $r['codigo'], 'producto' => $r['producto'], 'stock' => $stock,
                            'stock_minimo' => $min, 'venta_diaria' => round($vd, 3), 'dias_cobertura' => $diasInv,
                            'dias_reposicion' => $lead, 'punto_pedido' => round($punto, 1), 'sugerido' => $sugerido,
                            'costo_estimado' => round($sugerido * (float)$r['precio_compra'], 2),
                            'urgencia' => $stock <= $min ? 'ALTA' : ($diasInv !== null && $diasInv < $lead ? 'MEDIA' : 'BAJA')];
                    }
                }
                if ($tipo === 'rotacion') usort($rows, fn($a, $b) => $b['valor_costo'] <=> $a['valor_costo']);
                else { $peso = ['ALTA' => 0, 'MEDIA' => 1, 'BAJA' => 2];
                       usort($rows, fn($a, $b) => [$peso[$a['urgencia']], -$a['sugerido']] <=> [$peso[$b['urgencia']], -$b['sugerido']]); }
                break;

            case 'quiebres':
                // Intervalos con saldo 0 por (producto, almacen) segun el kardex, recortados al periodo
                $movs = DB::q('SELECT m.producto_id, m.almacen_id, m.fecha, m.saldo_resultante FROM movimiento m
                               JOIN producto p ON p.id = m.producto_id
                               WHERE m.empresa_id = ? AND p.activo = 1 AND m.fecha <= ? ORDER BY m.producto_id, m.almacen_id, m.fecha, m.id',
                              [$eid, $hasta])->fetchAll();
                $t0 = strtotime($desde); $t1 = strtotime($hasta); $porProd = [];
                $clave = null; $pid = 0; $ceroDesde = null;
                $cerrar = function (int $pid, int $hastaTs) use (&$porProd, &$ceroDesde, $t0) {
                    if ($ceroDesde === null) return;
                    $ini = max($ceroDesde, $t0);
                    if ($hastaTs > $ini) $porProd[$pid] = ($porProd[$pid] ?? 0) + ($hastaTs - $ini) / 86400;
                    $ceroDesde = null;
                };
                foreach ($movs as $m) {
                    $k = $m['producto_id'] . '-' . $m['almacen_id']; $ts = strtotime($m['fecha']);
                    if ($k !== $clave) { if ($clave !== null) $cerrar($pid, $t1); $clave = $k; $pid = (int)$m['producto_id']; $ceroDesde = null; }
                    if ((float)$m['saldo_resultante'] <= 0) { if ($ceroDesde === null) $ceroDesde = $ts; }
                    else { $cerrar($pid, $ts); }
                }
                if ($clave !== null) $cerrar($pid, $t1);
                if ($porProd) {
                    $ids = implode(',', array_map('intval', array_keys($porProd)));
                    $info = DB::q('SELECT p.id, p.codigo_interno codigo, p.nombre producto, p.precio_venta,
                                     (SELECT COALESCE(SUM(vd.cantidad), 0) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                                        WHERE vd.producto_id = p.id AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 90 DAY)) / 90 venta_diaria,
                                     COALESCE((SELECT SUM(cantidad) FROM stock s WHERE s.producto_id = p.id), 0) stock
                                   FROM producto p WHERE p.id IN (' . $ids . ')')->fetchAll();
                    foreach ($info as $i) {
                        $dias = round($porProd[$i['id']], 1);
                        $rows[] = ['codigo' => $i['codigo'], 'producto' => $i['producto'], 'dias_en_cero' => $dias,
                            'venta_diaria' => round((float)$i['venta_diaria'], 3),
                            'unidades_perdidas' => round($dias * (float)$i['venta_diaria'], 1),
                            'venta_perdida' => round($dias * (float)$i['venta_diaria'] * (float)$i['precio_venta'], 2),
                            'stock_actual' => (float)$i['stock']];
                    }
                    usort($rows, fn($a, $b) => $b['venta_perdida'] <=> $a['venta_perdida']);
                }
                break;

            // ---------------- COMPRAS E IMPORTACIONES ----------------
            case 'compras_proveedor':
                $rows = DB::q('SELECT COALESCE(pr.razon_social, "Sin proveedor") proveedor, pr.nit,
                          COUNT(DISTINCT co.id) compras, COUNT(DISTINCT cd.producto_id) productos,
                          ROUND(SUM(cd.cantidad * cd.costo_unit), 2) total,
                          ROUND(SUM(cd.cantidad * (COALESCE(cd.costo_landed_unit, cd.costo_unit) - cd.costo_unit)), 2) costos_importacion,
                          ROUND(SUM(cd.cantidad * COALESCE(cd.costo_landed_unit, cd.costo_unit)), 2) total_landed,
                          MAX(co.fecha) ultima_compra, DATEDIFF(NOW(), MAX(co.fecha)) dias_desde_ultima
                        FROM compra_detalle cd JOIN compra co ON co.id = cd.compra_id
                        LEFT JOIN proveedor pr ON pr.id = co.proveedor_id
                        WHERE co.empresa_id = ? AND co.fecha BETWEEN ? AND ? AND co.estado != "ANULADA"
                        GROUP BY co.proveedor_id ORDER BY total_landed DESC', [$eid, $desde, $hasta])->fetchAll();
                break;

            case 'evolucion_costos':
                $raw = DB::q('SELECT p.codigo_interno codigo, p.nombre producto, co.id compra, co.fecha,
                          COALESCE(pr.razon_social, "S/N") proveedor, cd.cantidad, cd.costo_unit,
                          COALESCE(cd.costo_landed_unit, cd.costo_unit) costo_landed
                        FROM compra_detalle cd JOIN compra co ON co.id = cd.compra_id
                        JOIN producto p ON p.id = cd.producto_id LEFT JOIN proveedor pr ON pr.id = co.proveedor_id
                        WHERE co.empresa_id = ? AND co.fecha BETWEEN ? AND ? AND co.estado != "ANULADA"
                        ORDER BY p.nombre, co.fecha', [$eid, $desde, $hasta])->fetchAll();
                $prev = [];
                foreach ($raw as $r) {
                    $k = $r['codigo']; $landed = (float)$r['costo_landed'];
                    $r['variacion_pct'] = isset($prev[$k]) && $prev[$k] > 0 ? round(($landed - $prev[$k]) / $prev[$k] * 100, 1) : null;
                    $prev[$k] = $landed; $rows[] = $r;
                }
                break;

            case 'importaciones':
                $raw = DB::q('SELECT co.id compra, co.fecha, COALESCE(pr.razon_social, "S/N") proveedor, co.nro_documento,
                          co.moneda, co.tipo_cambio, co.total_moneda fob_moneda, co.total fob_bs,
                          co.costos_adicionales, co.total_costos, co.total_landed,
                          IF(co.total > 0, ROUND(co.total_landed / co.total, 3), NULL) factor
                        FROM compra co LEFT JOIN proveedor pr ON pr.id = co.proveedor_id
                        WHERE co.empresa_id = ? AND co.fecha BETWEEN ? AND ? AND co.estado != "ANULADA"
                          AND (co.total_costos > 0 OR co.moneda != "BOB")
                        ORDER BY co.fecha DESC', [$eid, $desde, $hasta])->fetchAll();
                foreach ($raw as $r) {
                    $det = json_decode($r['costos_adicionales'] ?? '[]', true) ?: [];
                    $r['costos_detalle'] = implode(' · ', array_map(fn($c) => $c['concepto'] . ' ' . number_format((float)$c['monto'], 2), $det));
                    unset($r['costos_adicionales']); $rows[] = $r;
                }
                break;

            // ---------------- TRIBUTARIO ----------------
            case 'libro_ventas':
                $raw = DB::q('SELECT f.fecha_emision, f.numero_factura, f.cuf, f.cliente_snapshot, f.monto_total, f.estado
                        FROM factura f JOIN siat_config sc ON sc.id = f.siat_config_id
                        JOIN sucursal su ON su.id = sc.sucursal_id
                        WHERE su.empresa_id = ? AND f.fecha_emision BETWEEN ? AND ? AND f.estado IN ("VALIDA","ANULADA")
                        ORDER BY f.fecha_emision, f.numero_factura', [$eid, $desde, $hasta])->fetchAll();
                $n = 0;
                foreach ($raw as $f) {
                    $c = json_decode($f['cliente_snapshot'] ?? '{}', true) ?: [];
                    $anulada = $f['estado'] === 'ANULADA'; $tot = $anulada ? 0 : (float)$f['monto_total'];
                    $rows[] = ['nro' => ++$n, 'fecha_factura' => substr($f['fecha_emision'], 0, 10),
                        'nro_factura' => $f['numero_factura'], 'autorizacion' => $f['cuf'],
                        'nit_ci_cliente' => $c['num_documento'] ?? $c['numeroDocumento'] ?? '', 'complemento' => $c['complemento'] ?? '',
                        'razon_social' => $c['razon_social'] ?? $c['nombreRazonSocial'] ?? '',
                        'importe_total' => $tot, 'importe_ice' => 0, 'importe_iehd' => 0, 'importe_ipj' => 0, 'tasas' => 0,
                        'otros_no_sujetos' => 0, 'exportaciones_exentas' => 0, 'tasa_cero' => 0,
                        'subtotal' => $tot, 'descuentos' => 0, 'base_debito_fiscal' => $tot,
                        'debito_fiscal' => round($tot * 0.13, 2), 'estado' => $anulada ? 'A' : 'V',
                        'codigo_control' => '0', 'tipo_venta' => 0];
                }
                break;

            case 'libro_compras':
                $raw = DB::q('SELECT fr.fecha_emision, fr.nit_proveedor, fr.razon_social, fr.numero_factura, fr.cuf,
                          fr.codigo_control, fr.monto_total, fr.compra_id
                        FROM factura_recibida fr WHERE fr.empresa_id = ? AND fr.fecha_emision BETWEEN ? AND ?
                        ORDER BY fr.fecha_emision, fr.numero_factura', [$eid, $desde, $hasta])->fetchAll();
                $n = 0;
                foreach ($raw as $f) {
                    $tot = (float)$f['monto_total'];
                    $rows[] = ['nro' => ++$n, 'fecha_factura' => substr((string)$f['fecha_emision'], 0, 10),
                        'nit_proveedor' => $f['nit_proveedor'], 'razon_social' => $f['razon_social'],
                        'nro_factura' => $f['numero_factura'], 'autorizacion' => $f['cuf'],
                        'importe_total' => $tot, 'importe_ice' => 0, 'importe_iehd' => 0, 'importe_ipj' => 0, 'tasas' => 0,
                        'otros_no_sujetos' => 0, 'exentos' => 0, 'tasa_cero' => 0,
                        'subtotal' => $tot, 'descuentos' => 0, 'base_credito_fiscal' => $tot,
                        'credito_fiscal' => round($tot * 0.13, 2), 'tipo_compra' => 1,
                        'codigo_control' => $f['codigo_control'] ?: '0', 'compra_interna' => $f['compra_id']];
                }
                break;

            case 'aging':
                $sql = 'SELECT "%s" tipo, COALESCE(t.razon_social, "S/N") tercero,
                          COUNT(*) documentos, ROUND(SUM(x.total), 2) total,
                          ROUND(SUM(IF(DATEDIFF(NOW(), x.fecha) <= 30, x.total, 0)), 2) d_0_30,
                          ROUND(SUM(IF(DATEDIFF(NOW(), x.fecha) BETWEEN 31 AND 60, x.total, 0)), 2) d_31_60,
                          ROUND(SUM(IF(DATEDIFF(NOW(), x.fecha) BETWEEN 61 AND 90, x.total, 0)), 2) d_61_90,
                          ROUND(SUM(IF(DATEDIFF(NOW(), x.fecha) > 90, x.total, 0)), 2) d_mas_90,
                          MAX(DATEDIFF(NOW(), x.fecha)) dias_max
                        FROM %s x LEFT JOIN %s t ON t.id = x.%s
                        WHERE x.empresa_id = ? AND x.pagada = 0 AND x.estado %s GROUP BY x.%s ORDER BY total DESC';
                $rows = array_merge(
                    DB::q(sprintf($sql, 'CXC', 'venta', 'cliente', 'cliente_id', '= "COMPLETADA"', 'cliente_id'), [$eid])->fetchAll(),
                    DB::q(sprintf($sql, 'CXP', 'compra', 'proveedor', 'proveedor_id', '!= "ANULADA"', 'proveedor_id'), [$eid])->fetchAll());
                break;

            // ---------------- PROFORMAS ----------------
            case 'proformas':
                $rows = DB::q('SELECT COALESCE(us.nombre, "-") vendedor, COUNT(*) emitidas,
                          SUM(p.estado = "ENVIADA") enviadas, SUM(p.estado = "ACEPTADA") aceptadas,
                          SUM(p.estado = "CONVERTIDA") convertidas, SUM(p.estado = "VENCIDA") vencidas,
                          SUM(p.estado = "ANULADA") anuladas, ROUND(SUM(p.total), 2) monto_emitido,
                          ROUND(SUM(IF(p.estado = "CONVERTIDA", p.total, 0)), 2) monto_convertido,
                          ROUND(SUM(p.estado = "CONVERTIDA") / COUNT(*) * 100, 1) tasa_conversion_pct,
                          ROUND(AVG(IF(p.estado = "CONVERTIDA", DATEDIFF(v.fecha, p.creado_en), NULL)), 1) dias_promedio_conversion
                        FROM proforma p LEFT JOIN usuario us ON us.id = p.usuario_id
                        LEFT JOIN venta v ON v.id = p.venta_id
                        WHERE p.empresa_id = ? AND p.creado_en BETWEEN ? AND ?
                        GROUP BY COALESCE(us.nombre, "-") WITH ROLLUP', [$eid, $desde, $hasta])->fetchAll();
                foreach ($rows as &$r) if ($r['vendedor'] === null) $r['vendedor'] = 'TOTAL';
                unset($r);
                break;
        }
        return $rows;
    }

    /** Suma de las columnas numericas conocidas (para el pie de la tabla). */
    public static function totales(array $rows): array
    {
        $totales = [];
        foreach (['total','monto_total','valor_costo','valor_venta','stock','margen','venta_total','costo_total',
                  'total_landed','costos_importacion','importe_total','debito_fiscal','credito_fiscal','venta_perdida',
                  'costo_estimado','d_0_30','d_31_60','d_61_90','d_mas_90','compras'] as $col) {
            if ($rows && array_key_exists($col, $rows[0])) {
                $totales[$col] = round(array_sum(array_column($rows, $col)), 2);
            }
        }
        return $totales;
    }

    /** Descarga CSV compatible con Excel (BOM UTF-8, separador ;). Termina la peticion. */
    public static function exportarCsv(string $nombre, array $rows): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="informe_' . $nombre . '_' . date('Ymd') . '.csv"');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        if ($rows) {
            fputcsv($out, array_keys($rows[0]), ';');
            foreach ($rows as $r) fputcsv($out, array_map(fn($v) => $v ?? '', array_values($r)), ';');
        }
        fclose($out);
        exit;
    }
}
