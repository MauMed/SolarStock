<?php
namespace Api;

use Core\DB;

/**
 * KPIs del panel de inicio. Cada KPI devuelve valor, valor del periodo
 * anterior (para la variacion), formato y, cuando aplica, semaforo y serie.
 * Solo se calculan los KPIs visibles para la empresa (Marca > Informes y
 * KPIs visibles), asi el panel no paga consultas por tarjetas apagadas.
 */
class Kpis
{
    /** clave => [nombre, formato (bs|pct|num|dias|lista), descripcion, informe al que enlaza] */
    public const CATALOGO = [
        'ventas'          => ['Ventas del periodo', 'bs', 'Total vendido y variacion contra el periodo anterior', 'ventas'],
        'num_ventas'      => ['Numero de ventas', 'num', 'Cantidad de ventas del periodo', 'ventas'],
        'ticket_promedio' => ['Ticket promedio', 'bs', 'Venta promedio por transaccion', 'ventas_cliente'],
        'margen_pct'      => ['Margen bruto %', 'pct', 'Semaforo segun el margen objetivo de la empresa', 'margen'],
        'facturado_pct'   => ['Facturado con SIAT %', 'pct', 'Parte de las ventas del periodo con factura VALIDA', 'facturas'],
        'dias_inventario' => ['Dias de inventario', 'dias', 'Stock a costo dividido entre la venta diaria a costo (90 dias)', 'rotacion'],
        'inmovilizado'    => ['Inventario inmovilizado', 'bs', 'Valor a costo de productos sin ventas en 90 dias', 'rotacion'],
        'bajo_minimo'     => ['Productos bajo minimo', 'num', 'Productos con stock igual o menor al minimo', 'reposicion'],
        'cxc_vencida'     => ['CxC vencida', 'bs', 'Cuentas por cobrar con mas de 30 dias y % sobre la cartera', 'aging'],
        'conversion_prof' => ['Conversion de proformas %', 'pct', 'Proformas del periodo que terminaron en venta', 'proformas'],
        'top_productos'   => ['Top 5 productos', 'lista', 'Mas vendidos del periodo (unidades)', 'ventas_categoria'],
        'top_clientes'    => ['Top 5 clientes', 'lista', 'Mayor monto comprado en el periodo', 'ventas_cliente'],
    ];

    /** Rangos [desde, hasta, desdeAnterior, hastaAnterior] para hoy|semana|mes|anio|rango. */
    public static function rangos(string $periodo, ?string $desde = null, ?string $hasta = null): array
    {
        $hoy = new \DateTimeImmutable('today');
        switch ($periodo) {
            case 'hoy':    $d0 = $hoy; $d1 = $hoy; break;
            case 'semana': $d0 = $hoy->modify('monday this week'); $d1 = $hoy; break;
            case 'anio':   $d0 = $hoy->modify('first day of january'); $d1 = $hoy; break;
            case 'rango':  $d0 = new \DateTimeImmutable($desde ?: 'first day of this month'); $d1 = new \DateTimeImmutable($hasta ?: 'today'); break;
            default:       $d0 = $hoy->modify('first day of this month'); $d1 = $hoy; $periodo = 'mes';
        }
        $dias = $d0->diff($d1)->days + 1;
        $p1 = $d0->modify('-1 day'); $p0 = $p1->modify('-' . ($dias - 1) . ' days');
        return [$d0->format('Y-m-d'), $d1->format('Y-m-d 23:59:59'), $p0->format('Y-m-d'), $p1->format('Y-m-d 23:59:59'), $periodo, $dias];
    }

    public static function calcular(int $eid, string $periodo, ?string $desde = null, ?string $hasta = null): array
    {
        [$a0, $a1, $b0, $b1, $periodo, $dias] = self::rangos($periodo, $desde, $hasta);
        $ocultos = Informes::visibilidad($eid)['kpis_ocultos'];
        $emp = DB::q('SELECT margen_objetivo_pct FROM empresa WHERE id = ?', [$eid])->fetch();
        $out = ['periodo' => $periodo, 'desde' => $a0, 'hasta' => substr($a1, 0, 10),
                'anterior_desde' => $b0, 'anterior_hasta' => substr($b1, 0, 10), 'kpis' => []];

        $ventas = fn($x0, $x1) => DB::q('SELECT COUNT(DISTINCT v.id) n, COALESCE(SUM(vd.cantidad * vd.precio_unit - vd.descuento), 0) total,
                COALESCE(SUM(vd.cantidad * p.precio_compra), 0) costo
              FROM venta v JOIN venta_detalle vd ON vd.venta_id = v.id JOIN producto p ON p.id = vd.producto_id
              WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"', [$eid, $x0, $x1])->fetch();
        $necesitaVentas = array_intersect(['ventas', 'num_ventas', 'ticket_promedio', 'margen_pct', 'facturado_pct'], array_diff(array_keys(self::CATALOGO), $ocultos));
        $va = $vb = null;
        if ($necesitaVentas) { $va = $ventas($a0, $a1); $vb = $ventas($b0, $b1); }

        foreach (self::CATALOGO as $k => [$nombre, $fmt, $desc, $informe]) {
            if (in_array($k, $ocultos, true)) continue;
            $kpi = ['clave' => $k, 'nombre' => $nombre, 'formato' => $fmt, 'informe' => $informe];
            switch ($k) {
                case 'ventas':
                    $kpi += ['valor' => round((float)$va['total'], 2), 'anterior' => round((float)$vb['total'], 2)];
                    $kpi['serie'] = array_map('floatval', array_column(self::serieDiaria($eid, $a0, $a1, $dias), 't'));
                    break;
                case 'num_ventas':
                    $kpi += ['valor' => (int)$va['n'], 'anterior' => (int)$vb['n']]; break;
                case 'ticket_promedio':
                    $kpi += ['valor' => $va['n'] ? round($va['total'] / $va['n'], 2) : 0,
                             'anterior' => $vb['n'] ? round($vb['total'] / $vb['n'], 2) : 0]; break;
                case 'margen_pct':
                    $m = fn($v) => $v['total'] > 0 ? round(($v['total'] - $v['costo']) / $v['total'] * 100, 1) : 0;
                    $obj = (float)$emp['margen_objetivo_pct'];
                    $kpi += ['valor' => $m($va), 'anterior' => $m($vb), 'objetivo' => $obj,
                             'semaforo' => $m($va) >= $obj ? 'verde' : ($m($va) >= $obj * 0.8 ? 'amarillo' : 'rojo')];
                    break;
                case 'facturado_pct':
                    $f = fn($x0, $x1) => (float)DB::q('SELECT COALESCE(SUM(f.monto_total), 0) t FROM factura f
                          JOIN siat_config sc ON sc.id = f.siat_config_id JOIN sucursal su ON su.id = sc.sucursal_id
                          WHERE su.empresa_id = ? AND f.fecha_emision BETWEEN ? AND ? AND f.estado = "VALIDA"', [$eid, $x0, $x1])->fetch()['t'];
                    $kpi += ['valor' => $va['total'] > 0 ? round($f($a0, $a1) / $va['total'] * 100, 1) : 0,
                             'anterior' => $vb['total'] > 0 ? round($f($b0, $b1) / $vb['total'] * 100, 1) : 0];
                    break;
                case 'dias_inventario':
                    $r = DB::q('SELECT COALESCE(SUM(s.cantidad * p.precio_compra), 0) inv,
                          (SELECT COALESCE(SUM(vd.cantidad * p2.precio_compra), 0) FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                             JOIN producto p2 ON p2.id = vd.producto_id
                             WHERE v.empresa_id = ? AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 90 DAY)) / 90 cmv_diario
                        FROM stock s JOIN producto p ON p.id = s.producto_id WHERE p.empresa_id = ? AND p.activo = 1', [$eid, $eid])->fetch();
                    $kpi += ['valor' => (float)$r['cmv_diario'] > 0 ? (int)round($r['inv'] / $r['cmv_diario']) : null,
                             'anterior' => null, 'detalle' => 'Inventario a costo Bs ' . number_format((float)$r['inv'], 2)];
                    break;
                case 'inmovilizado':
                    $r = DB::q('SELECT COALESCE(SUM(s.cantidad * p.precio_compra), 0) v, COUNT(DISTINCT p.id) n
                        FROM producto p JOIN stock s ON s.producto_id = p.id
                        WHERE p.empresa_id = ? AND p.activo = 1 AND s.cantidad > 0 AND p.id NOT IN (
                          SELECT vd.producto_id FROM venta_detalle vd JOIN venta v ON v.id = vd.venta_id
                          WHERE v.empresa_id = ? AND v.estado = "COMPLETADA" AND v.fecha >= DATE_SUB(NOW(), INTERVAL 90 DAY))', [$eid, $eid])->fetch();
                    $kpi += ['valor' => round((float)$r['v'], 2), 'anterior' => null, 'detalle' => $r['n'] . ' producto(s) sin ventas en 90 dias',
                             'semaforo' => (float)$r['v'] > 0 ? 'amarillo' : 'verde'];
                    break;
                case 'bajo_minimo':
                    $n = DB::q('SELECT COUNT(*) c FROM (SELECT p.id FROM producto p LEFT JOIN stock s ON s.producto_id = p.id
                        WHERE p.empresa_id = ? AND p.activo = 1 GROUP BY p.id HAVING COALESCE(SUM(s.cantidad), 0) <= MAX(p.stock_minimo)) x', [$eid])->fetch()['c'];
                    $kpi += ['valor' => (int)$n, 'anterior' => null, 'semaforo' => $n > 0 ? 'rojo' : 'verde'];
                    break;
                case 'cxc_vencida':
                    $r = DB::q('SELECT COALESCE(SUM(IF(fecha < DATE_SUB(NOW(), INTERVAL 30 DAY), total, 0)), 0) vencida,
                          COALESCE(SUM(total), 0) cartera FROM venta WHERE empresa_id = ? AND pagada = 0 AND estado = "COMPLETADA"', [$eid])->fetch();
                    $pct = (float)$r['cartera'] > 0 ? round($r['vencida'] / $r['cartera'] * 100, 1) : 0;
                    $kpi += ['valor' => round((float)$r['vencida'], 2), 'anterior' => null, 'detalle' => $pct . '% de la cartera (Bs ' . number_format((float)$r['cartera'], 2) . ')',
                             'semaforo' => $pct >= 30 ? 'rojo' : ($pct > 0 ? 'amarillo' : 'verde')];
                    break;
                case 'conversion_prof':
                    $c = fn($x0, $x1) => DB::q('SELECT COUNT(*) n, SUM(estado = "CONVERTIDA") conv FROM proforma
                          WHERE empresa_id = ? AND creado_en BETWEEN ? AND ?', [$eid, $x0, $x1])->fetch();
                    $ca = $c($a0, $a1); $cb = $c($b0, $b1);
                    $kpi += ['valor' => $ca['n'] ? round($ca['conv'] / $ca['n'] * 100, 1) : 0,
                             'anterior' => $cb['n'] ? round($cb['conv'] / $cb['n'] * 100, 1) : 0,
                             'detalle' => (int)$ca['conv'] . ' de ' . (int)$ca['n'] . ' proformas'];
                    break;
                case 'top_productos':
                    $kpi += ['valor' => DB::q('SELECT p.nombre etiqueta, SUM(vd.cantidad) valor FROM venta_detalle vd
                          JOIN venta v ON v.id = vd.venta_id JOIN producto p ON p.id = vd.producto_id
                          WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                          GROUP BY p.id ORDER BY valor DESC LIMIT 5', [$eid, $a0, $a1])->fetchAll(), 'unidad' => 'u.'];
                    break;
                case 'top_clientes':
                    $kpi += ['valor' => DB::q('SELECT COALESCE(c.razon_social, "S/N") etiqueta, ROUND(SUM(v.total), 2) valor FROM venta v
                          LEFT JOIN cliente c ON c.id = v.cliente_id
                          WHERE v.empresa_id = ? AND v.fecha BETWEEN ? AND ? AND v.estado = "COMPLETADA"
                          GROUP BY v.cliente_id ORDER BY valor DESC LIMIT 5', [$eid, $a0, $a1])->fetchAll(), 'unidad' => 'Bs'];
                    break;
            }
            if (isset($kpi['anterior']) && $kpi['anterior'] !== null && is_numeric($kpi['valor'] ?? null)) {
                $kpi['variacion_pct'] = $kpi['anterior'] > 0 ? round(($kpi['valor'] - $kpi['anterior']) / $kpi['anterior'] * 100, 1) : null;
            }
            $out['kpis'][] = $kpi;
        }
        return $out;
    }

    /** Serie diaria de ventas (o mensual si el periodo es largo) para la mini grafica. */
    private static function serieDiaria(int $eid, string $d0, string $d1, int $dias): array
    {
        $agr = $dias > 62 ? 'DATE_FORMAT(fecha, "%Y-%m")' : 'DATE(fecha)';
        return DB::q('SELECT ' . $agr . ' d, SUM(total) t FROM venta WHERE empresa_id = ? AND fecha BETWEEN ? AND ?
                      AND estado = "COMPLETADA" GROUP BY d ORDER BY d', [$eid, $d0, $d1])->fetchAll();
    }

    /** Catalogo con marca visible/oculto para la pantalla de interruptores. */
    public static function catalogo(int $eid): array
    {
        $oc = Informes::visibilidad($eid)['kpis_ocultos'];
        $out = [];
        foreach (self::CATALOGO as $k => [$nombre, $fmt, $desc, $informe]) {
            $out[] = ['clave' => $k, 'nombre' => $nombre, 'formato' => $fmt, 'descripcion' => $desc,
                      'informe' => $informe, 'visible' => !in_array($k, $oc, true)];
        }
        return $out;
    }
}
