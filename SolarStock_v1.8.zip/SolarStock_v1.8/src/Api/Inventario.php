<?php
namespace Api;

use Core\DB;
use Integrations\Webhooks;

/**
 * Logica central de inventario. Toda entrada/salida pasa por movimiento()
 * para que el kardex sea la unica fuente de verdad.
 */
class Inventario
{
    public static function movimiento(int $empresaId, int $productoId, int $almacenId,
        string $tipo, float $cantidad, float $costo = 0,
        ?string $refTipo = null, ?int $refId = null, ?int $usuarioId = null): float
    {
        return DB::tx(function () use ($empresaId, $productoId, $almacenId, $tipo, $cantidad, $costo, $refTipo, $refId, $usuarioId) {
            $signo = in_array($tipo, ['COMPRA', 'AJUSTE+', 'TRASPASO_IN', 'DEVOLUCION']) ? 1 : -1;
            DB::q('INSERT INTO stock (producto_id, almacen_id, cantidad) VALUES (?,?,0)
                   ON DUPLICATE KEY UPDATE cantidad = cantidad', [$productoId, $almacenId]);
            // Lock pesimista para evitar sobreventa con cajas concurrentes
            $st = DB::q('SELECT cantidad FROM stock WHERE producto_id = ? AND almacen_id = ? FOR UPDATE',
                        [$productoId, $almacenId])->fetch();
            $nuevo = (float)$st['cantidad'] + $signo * $cantidad;
            if ($nuevo < 0) throw new \RuntimeException('STOCK_INSUFICIENTE');
            DB::q('UPDATE stock SET cantidad = ? WHERE producto_id = ? AND almacen_id = ?',
                  [$nuevo, $productoId, $almacenId]);
            DB::q('INSERT INTO movimiento (empresa_id, producto_id, almacen_id, tipo, cantidad, costo_unit,
                     saldo_resultante, referencia_tipo, referencia_id, usuario_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?)',
                  [$empresaId, $productoId, $almacenId, $tipo, $cantidad, $costo, $nuevo, $refTipo, $refId, $usuarioId]);

            $prod = DB::q('SELECT nombre, stock_minimo FROM producto WHERE id = ?', [$productoId])->fetch();
            if ($nuevo <= (float)$prod['stock_minimo']) {
                Webhooks::disparar($empresaId, 'stock.bajo', [
                    'producto_id' => $productoId, 'nombre' => $prod['nombre'],
                    'almacen_id' => $almacenId, 'stock' => $nuevo, 'minimo' => $prod['stock_minimo'],
                ]);
            }
            return $nuevo;
        });
    }

    /**
     * Crea una venta y descuenta stock en UNA sola transaccion: si cualquier
     * item no tiene stock, no queda ni la venta ni descuentos parciales.
     *
     * Entrada: almacen_id (obligatorio), items[{producto_id, cantidad, precio_unit, descuento?}],
     *          cliente_id?, descuento?, metodo_pago_sin?, origen?, punto_venta_id?
     * sucursal_id y punto_venta_id se resuelven en el servidor a partir del
     * almacen: el cliente ya no necesita (ni puede) mandar IDs de otra empresa.
     */
    /** Almacen (con su sucursal) verificando que pertenezca a la empresa. */
    public static function almacenDeEmpresa(int $eid, int $almacenId): array
    {
        return DB::q('SELECT a.id, a.sucursal_id, a.nombre FROM almacen a JOIN sucursal s ON s.id = a.sucursal_id
                      WHERE a.id = ? AND s.empresa_id = ?', [$almacenId, $eid])->fetch()
            ?: throw new \RuntimeException('Almacen no valido para esta empresa');
    }

    /**
     * Resuelve el cliente de una venta/proforma:
     *  - $in['cliente_id']: se usa si es de la empresa.
     *  - $in['cliente'] = {tipo_doc_sin, num_documento, complemento?, razon_social, email?, telefono?}:
     *    busca por (empresa, tipo_doc, num_documento, complemento); si existe actualiza
     *    razon social / email / telefono, si no lo crea. tipo_doc 0 o sin numero => null (99001).
     * Devuelve el id o null.
     */
    public static function resolverCliente(int $eid, array $in): ?int
    {
        if (!empty($in['cliente_id'])) {
            $c = DB::q('SELECT id FROM cliente WHERE id = ? AND empresa_id = ?', [(int)$in['cliente_id'], $eid])->fetch();
            if ($c) return (int)$c['id'];
        }
        $c = $in['cliente'] ?? null;
        if (!is_array($c)) return null;
        $tipo = (int)($c['tipo_doc_sin'] ?? 1);
        $num = trim((string)($c['num_documento'] ?? ''));
        $rs = mb_substr(trim((string)($c['razon_social'] ?? '')), 0, 200);
        if ($tipo === 0 || $num === '' || $rs === '') return null;
        $comp = mb_substr(trim((string)($c['complemento'] ?? '')), 0, 3) ?: null;
        $email = trim((string)($c['email'] ?? '')) ?: null;
        $tel = trim((string)($c['telefono'] ?? '')) ?: null;
        $ex = DB::q('SELECT id FROM cliente WHERE empresa_id = ? AND tipo_doc_sin = ? AND num_documento = ?
                     AND COALESCE(complemento, "") = ? LIMIT 1', [$eid, $tipo, $num, $comp ?? ''])->fetch();
        if ($ex) {
            DB::q('UPDATE cliente SET razon_social = ?, email = COALESCE(?, email), telefono = COALESCE(?, telefono) WHERE id = ?',
                  [$rs, $email, $tel, $ex['id']]);
            return (int)$ex['id'];
        }
        DB::q('INSERT INTO cliente (empresa_id, tipo_doc_sin, num_documento, complemento, razon_social, email, telefono)
               VALUES (?,?,?,?,?,?,?)', [$eid, $tipo, $num, $comp, $rs, $email, $tel]);
        return DB::insertId();
    }

    public static function crearVenta(array $u, array $in): array
    {
        $eid = (int)$u['empresa_id'];
        $items = $in['items'] ?? [];
        if (!is_array($items) || !$items) throw new \RuntimeException('La venta no tiene items');

        // Almacen y sucursal: deben pertenecer a la empresa del usuario
        $alm = self::almacenDeEmpresa($eid, (int)($in['almacen_id'] ?? 0));
        $almacenId = (int)$alm['id']; $sucursalId = (int)$alm['sucursal_id'];

        // Punto de venta: el indicado (si es de la sucursal) o el primero de la sucursal
        $pdvId = null;
        if (!empty($in['punto_venta_id'])) {
            $pdv = DB::q('SELECT id FROM punto_venta WHERE id = ? AND sucursal_id = ?',
                         [(int)$in['punto_venta_id'], $sucursalId])->fetch();
            $pdvId = $pdv ? (int)$pdv['id'] : null;
        }
        if ($pdvId === null) {
            $pdv = DB::q('SELECT id FROM punto_venta WHERE sucursal_id = ? ORDER BY codigo_sin, id LIMIT 1',
                         [$sucursalId])->fetch();
            $pdvId = $pdv ? (int)$pdv['id'] : null;
        }

        // Cliente: por id o por datos del documento (se crea si no existe)
        $clienteId = self::resolverCliente($eid, $in);

        // Normalizar items y validar que los productos sean de la empresa
        $norm = [];
        foreach ($items as $it) {
            $pid = (int)($it['producto_id'] ?? 0);
            $cant = (float)($it['cantidad'] ?? 0);
            if ($pid <= 0 || $cant <= 0) throw new \RuntimeException('Item invalido: producto o cantidad');
            $p = DB::q('SELECT id, nombre, precio_venta FROM producto WHERE id = ? AND empresa_id = ? AND activo = 1', [$pid, $eid])->fetch()
                ?: throw new \RuntimeException("Producto $pid no existe o esta inactivo");
            $norm[] = [
                'producto_id' => $pid, 'nombre' => $p['nombre'], 'cantidad' => $cant,
                'precio_unit' => isset($it['precio_unit']) ? (float)$it['precio_unit'] : (float)$p['precio_venta'],
                'descuento' => (float)($it['descuento'] ?? 0),
            ];
        }

        $ventaId = DB::tx(function () use ($u, $in, $eid, $norm, $almacenId, $sucursalId, $pdvId, $clienteId) {
            $sub = 0;
            foreach ($norm as $it) $sub += $it['cantidad'] * $it['precio_unit'] - $it['descuento'];
            $desc = (float)($in['descuento'] ?? 0);
            DB::q('INSERT INTO venta (empresa_id, sucursal_id, punto_venta_id, almacen_id, cliente_id,
                     subtotal, descuento, total, metodo_pago_sin, origen, usuario_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                  [$eid, $sucursalId, $pdvId, $almacenId, $clienteId,
                   round($sub, 2), $desc, round($sub - $desc, 2), $in['metodo_pago_sin'] ?? 1,
                   $in['origen'] ?? 'POS', $u['id'] ?? null]);
            $ventaId = DB::insertId();
            foreach ($norm as $it) {
                DB::q('INSERT INTO venta_detalle (venta_id, producto_id, cantidad, precio_unit, descuento)
                       VALUES (?,?,?,?,?)',
                      [$ventaId, $it['producto_id'], $it['cantidad'], $it['precio_unit'], $it['descuento']]);
                // Mismo bloque transaccional: DB::tx anidado se une a esta transaccion
                try {
                    self::movimiento($eid, $it['producto_id'], $almacenId, 'VENTA',
                        $it['cantidad'], 0, 'venta', $ventaId, $u['id'] ?? null);
                } catch (\RuntimeException $e) {
                    if ($e->getMessage() === 'STOCK_INSUFICIENTE') {
                        throw new \RuntimeException('STOCK_INSUFICIENTE: ' . $it['nombre']);
                    }
                    throw $e;
                }
            }
            return $ventaId;
        });
        $venta = DB::q('SELECT * FROM venta WHERE id = ?', [$ventaId])->fetch();
        Webhooks::disparar($eid, 'venta.creada', $venta);
        return $venta;
    }
}
