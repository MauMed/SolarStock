<?php
namespace Core;

use PDO;

class DB
{
    private static ?PDO $pdo = null;
    private static int $txNivel = 0;          // profundidad de transacciones anidadas
    private static array $alConfirmar = [];   // callbacks a ejecutar tras el COMMIT externo

    public static function get(): PDO
    {
        if (self::$pdo === null) {
            $c = (require dirname(__DIR__, 2) . '/config/config.php')['db'];
            $dsn = "mysql:host={$c['host']};dbname={$c['name']};charset={$c['charset']}";
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }
        return self::$pdo;
    }

    public static function q(string $sql, array $params = []): \PDOStatement
    {
        $st = self::get()->prepare($sql);
        $st->execute($params);
        return $st;
    }

    public static function insertId(): int { return (int) self::get()->lastInsertId(); }

    /**
     * Ejecuta $fn dentro de una transaccion. Soporta anidamiento: si ya hay
     * una transaccion abierta, $fn se une a ella (no abre otra) y cualquier
     * excepcion revierte TODO el bloque externo. Asi crearVenta() puede
     * envolver varios movimiento() y que la venta sea atomica.
     */
    public static function tx(callable $fn)
    {
        $pdo = self::get();
        if (self::$txNivel > 0) {
            self::$txNivel++;
            try { return $fn($pdo); }
            finally { self::$txNivel--; }
        }
        self::$txNivel = 1;
        $pdo->beginTransaction();
        try {
            $r = $fn($pdo);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            self::$alConfirmar = [];
            throw $e;
        } finally {
            self::$txNivel = 0;
        }
        // Efectos secundarios (webhooks, correos) solo cuando los datos ya
        // estan confirmados y sin mantener locks de fila mientras se hacen
        // llamadas HTTP.
        $pend = self::$alConfirmar; self::$alConfirmar = [];
        foreach ($pend as $cb) { try { $cb(); } catch (\Throwable $e) { error_log('alConfirmar: ' . $e->getMessage()); } }
        return $r;
    }

    public static function enTransaccion(): bool { return self::$txNivel > 0; }

    /** Registra un callback para despues del COMMIT; fuera de transaccion se ejecuta de inmediato. */
    public static function alConfirmar(callable $cb): void
    {
        if (self::$txNivel > 0) self::$alConfirmar[] = $cb;
        else $cb();
    }
}
