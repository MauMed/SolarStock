<?php
// Router para php -S: sirve archivos estaticos existentes (como hace .htaccess) y el resto va a index.php
$f = __DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($f !== __DIR__ . '/' && is_file($f)) return false;
require __DIR__ . '/index.php';
